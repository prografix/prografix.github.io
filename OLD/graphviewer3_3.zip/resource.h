//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GraphViewer.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_GRAPHVTYPE                  129
#define IDD_STLFILEDLG                  166
#define IDD_MOVEPROP                    176
#define stc32                           0x045f
#define IDC_STL_SMOOTH                  1223
#define IDC_STL_COLOR                   1224
#define IDC_SMAGNIFY                    1261
#define IDC_SANGLE                      1262
#define IDC_SDISTANCE                   1263
#define IDC_EDISTANCE                   1264
#define IDC_EANGLE                      1265
#define IDC_EMAGNIFY                    1266
#define ID_MOV_XM                       32771
#define ID_MOV_XP                       32772
#define ID_ROT_X_CW                     32773
#define ID_ROT_Y_CCW                    32774
#define ID_ROT_Y_CW                     32775
#define ID_MOV_ZM                       32776
#define ID_SCENE                        32776
#define ID_ROT_Z_CW                     32777
#define ID_ROT_Z_CCW                    32778
#define ID_ZOOM_OUT                     32779
#define ID_ZOOM_IN                      32780
#define ID_RESET                        32781
#define ID_MOV_YP                       32782
#define ID_MOV_YM                       32783
#define ID_ROT_X_CCW                    32784
#define ID_MOV_ZP                       32785
#define ID_RUN_FORWARD                  32786
#define ID_RUN_BACK                     32787
#define ID_RUN_STOP                     32788
#define ID_RUN_PAUSE                    32789
#define ID_IMPORT_STL                   32790

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32792
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
