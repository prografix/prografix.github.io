
#include "File.h"
#include "fileSTL.h"

///////////////////////////////////////////////////////////////////////////////
///////////// ������ � ������ ��������� ( ASCII ) STL-������ //////////////////
///////////////////////////////////////////////////////////////////////////////

ISTL::~ISTL() {}

/*
��������� ��� ���������� ( ASCII ) STL-�����:

solid [part name]
facet normal 0.576759 -0.415057 -0.703617
outer loop
vertex 2.22934 -0.992723 -0.862826
vertex 2.29245 -0.871852 -0.8824
vertex 2.41037 -0.777999 -0.841105
endloop
endfacet
...
endsolid [part name]
*/

bool loadSTLA ( ReadFile & file, ISTL & stl )
{
    bool isSolid = false;
    stl.clear();
    for(;;)
    {
        char c;
// ���������� �������
        do
        {
            if ( ! file.getc ( &c ) ) return isSolid;
        }
        while ( c == '\t' || c == ' ' );
// ������ �������� ����� solid
        if ( c != 's' ) return false;
        if ( ! file.getc ( &c ) || c != 'o' ) return false;
        if ( ! file.getc ( &c ) || c != 'l' ) return false;
        if ( ! file.getc ( &c ) || c != 'i' ) return false;
        if ( ! file.getc ( &c ) || c != 'd' ) return false;
// ���������� �������
        do
        {
            if ( ! file.getc ( &c ) ) return false;
        }
        while ( c == '\t' || c == ' ' );
// ������ ����������� �� ���� �� ������
        int n = 0;
        char text[80];
        while ( c != '\n' )
        {
           if ( n < 80 ) text[n++] = c;
           if ( ! file.getc ( &c ) ) return false;
        }
        stl.putSolidText ( n, text );
// ���������� �������
        do
        {
            if ( ! file.getc ( &c ) ) return false;
        }
        while ( c == '\t' || c == ' ' );
// ������ �������� ����� facet
        if ( c != 'f' ) return false;
m1:     if ( ! file.getc ( &c ) || c != 'a' ) return false;
        if ( ! file.getc ( &c ) || c != 'c' ) return false;
        if ( ! file.getc ( &c ) || c != 'e' ) return false;
        if ( ! file.getc ( &c ) || c != 't' ) return false;
// ���������� �������
        do
        {
            if ( ! file.getc ( &c ) ) return false;
        }
        while ( c == '\t' || c == ' ' );
// ������ �������� ����� normal
        if ( c != 'n' ) return false;
        if ( ! file.getc ( &c ) || c != 'o' ) return false;
        if ( ! file.getc ( &c ) || c != 'r' ) return false;
        if ( ! file.getc ( &c ) || c != 'm' ) return false;
        if ( ! file.getc ( &c ) || c != 'a' ) return false;
        if ( ! file.getc ( &c ) || c != 'l' ) return false;
// ������ ���������� �������
        ISTL::Facet facet;
		if ( ! read ( file, c, facet.norm.x ) || 
             ! read ( file, c, facet.norm.y ) || 
             ! read ( file, c, facet.norm.z ) ) return false;
// ������� �� ����� ������
		while ( c != '\n' && file.getc ( &c ) ) continue;
        if ( c != '\n' ) return false;
// ���������� �������
        do
        {
            if ( ! file.getc ( &c ) ) return false;
        }
        while ( c == '\t' || c == ' ' );
// ������ �������� ����� outer
        if ( c != 'o' ) return false;
        if ( ! file.getc ( &c ) || c != 'u' ) return false;
        if ( ! file.getc ( &c ) || c != 't' ) return false;
        if ( ! file.getc ( &c ) || c != 'e' ) return false;
        if ( ! file.getc ( &c ) || c != 'r' ) return false;
// ���������� �������
        do
        {
            if ( ! file.getc ( &c ) ) return false;
        }
        while ( c == '\t' || c == ' ' );
// ������ �������� ����� loop
        if ( c != 'l' ) return false;
        if ( ! file.getc ( &c ) || c != 'o' ) return false;
        if ( ! file.getc ( &c ) || c != 'o' ) return false;
        if ( ! file.getc ( &c ) || c != 'p' ) return false;
// ������� �� ����� ������
		while ( c != '\n' && file.getc ( &c ) ) continue;
        if ( c != '\n' ) return false;
        for ( int i = 0; i < 3; ++i )
        {
// ���������� �������
            do
            {
                if ( ! file.getc ( &c ) ) return false;
            }
            while ( c == '\t' || c == ' ' );
// ������ �������� ����� vertex
            if ( c != 'v' ) return false;
            if ( ! file.getc ( &c ) || c != 'e' ) return false;
            if ( ! file.getc ( &c ) || c != 'r' ) return false;
            if ( ! file.getc ( &c ) || c != 't' ) return false;
            if ( ! file.getc ( &c ) || c != 'e' ) return false;
            if ( ! file.getc ( &c ) || c != 'x' ) return false;
// ������ ���������� �������
		    if ( ! read ( file, c, facet.vert[i].x ) || 
                 ! read ( file, c, facet.vert[i].y ) || 
                 ! read ( file, c, facet.vert[i].z ) ) return false;
// ������� �� ����� ������
		    while ( c != '\n' && file.getc ( &c ) ) continue;
            if ( c != '\n' ) return false;
        }
        stl.putFacet ( facet );
// ���������� �������
        do
        {
            if ( ! file.getc ( &c ) ) return false;
        }
        while ( c == '\t' || c == ' ' );
// ������ �������� ����� endloop
        if ( c != 'e' ) return false;
        if ( ! file.getc ( &c ) || c != 'n' ) return false;
        if ( ! file.getc ( &c ) || c != 'd' ) return false;
        if ( ! file.getc ( &c ) || c != 'l' ) return false;
        if ( ! file.getc ( &c ) || c != 'o' ) return false;
        if ( ! file.getc ( &c ) || c != 'o' ) return false;
        if ( ! file.getc ( &c ) || c != 'p' ) return false;
// ������� �� ����� ������
		while ( c != '\n' && file.getc ( &c ) ) continue;
        if ( c != '\n' ) return false;
// ���������� �������
        do
        {
            if ( ! file.getc ( &c ) ) return false;
        }
        while ( c == '\t' || c == ' ' );
// ������ �������� ����� endfacet
        if ( c != 'e' ) return false;
        if ( ! file.getc ( &c ) || c != 'n' ) return false;
        if ( ! file.getc ( &c ) || c != 'd' ) return false;
        if ( ! file.getc ( &c ) || c != 'f' ) return false;
        if ( ! file.getc ( &c ) || c != 'a' ) return false;
        if ( ! file.getc ( &c ) || c != 'c' ) return false;
        if ( ! file.getc ( &c ) || c != 'e' ) return false;
        if ( ! file.getc ( &c ) || c != 't' ) return false;
// ������� �� ����� ������
		while ( c != '\n' && file.getc ( &c ) ) continue;
        if ( c != '\n' ) return false;
// ���������� �������
        do
        {
            if ( ! file.getc ( &c ) ) return false;
        }
        while ( c == '\t' || c == ' ' );
// ��������� ������ ��� facet ��� endsolid?
        if ( c == 'f' ) goto m1;
        if ( c != 'e' ) return false;
// ������ �������� ����� endfacet
        if ( ! file.getc ( &c ) || c != 'n' ) return false;
        if ( ! file.getc ( &c ) || c != 'd' ) return false;
        if ( ! file.getc ( &c ) || c != 's' ) return false;
        if ( ! file.getc ( &c ) || c != 'o' ) return false;
        if ( ! file.getc ( &c ) || c != 'l' ) return false;
        if ( ! file.getc ( &c ) || c != 'i' ) return false;
        if ( ! file.getc ( &c ) || c != 'd' ) return false;
// ������� �� ����� ������
		while ( c != '\n' && file.getc ( &c ) ) continue;
        isSolid = true;
    }
}

bool saveSTLA ( WriteFile & file, ISTL & stl, int prec )
{
    int ntext;
    const char * text = stl.getSolidText ( ntext );
    if ( file.write ( "solid ", 6, 1 ) != 1 ) return false;
    if ( file.write ( text, 1, ntext ) != ntext ) return false;
    if ( file.write ( "\n", 1, 1 ) != 1 ) return false;

    int nfacet;
    const ISTL::Facet * facet = stl.getFacet ( nfacet );
    for ( int i = 0; i < nfacet; ++i )
    {
        const ISTL::Facet & f = facet[i];
        if ( ! writeStr ( file, "facet normal " ) ) return false;
		if ( ! writeFlt ( file, f.norm.x, prec ) ) return false;
		if ( ! file.putc ( " " ) ) return false;
		if ( ! writeFlt ( file, f.norm.y, prec ) ) return false;
		if ( ! file.putc ( " " ) ) return false;
		if ( ! writeFlt ( file, f.norm.z, prec ) ) return false;
        if ( ! writeStr ( file, "\nouter loop\nvertex " ) ) return false;
		if ( ! writeFlt ( file, f.vert[0].x, prec ) ) return false;
		if ( ! file.putc ( " " ) ) return false;
		if ( ! writeFlt ( file, f.vert[0].y, prec ) ) return false;
		if ( ! file.putc ( " " ) ) return false;
		if ( ! writeFlt ( file, f.vert[0].z, prec ) ) return false;
        if ( ! writeStr ( file, "\nvertex " ) ) return false;
		if ( ! writeFlt ( file, f.vert[1].x, prec ) ) return false;
		if ( ! file.putc ( " " ) ) return false;
		if ( ! writeFlt ( file, f.vert[1].y, prec ) ) return false;
		if ( ! file.putc ( " " ) ) return false;
		if ( ! writeFlt ( file, f.vert[1].z, prec ) ) return false;
        if ( ! writeStr ( file, "\nvertex " ) ) return false;
		if ( ! writeFlt ( file, f.vert[2].x, prec ) ) return false;
		if ( ! file.putc ( " " ) ) return false;
		if ( ! writeFlt ( file, f.vert[2].y, prec ) ) return false;
		if ( ! file.putc ( " " ) ) return false;
		if ( ! writeFlt ( file, f.vert[2].z, prec ) ) return false;
		if ( ! writeStr ( file, "\nendloop\nendfacet\n" ) ) return false;
    }
	return writeStr ( file, "endsolid" );
}

///////////////////////////////////////////////////////////////////////////////
///////////////// ������ � ������ �������� STL-������ /////////////////////////
///////////////////////////////////////////////////////////////////////////////

/*
struct facet
{
    float normal[3];     // 12 ����
    float vertex[3][3];  // 36 ����
    unsigned short attr; // 2 �����
};

struct stl_file
{
    char head[80]; // �����������   - 80 ����
    long  int n;   // �-�� ������   - 4  �����
    facet arr[n];  // ������ ������ - n * 50 ����
};
*/

bool loadSTLB ( ReadFile & file, ISTL & stl )
{
    char text[80];
    if ( file.read ( text, 80, 1 ) != 1 ) return false;
    int nsides;
    if ( file.read ( &nsides, 4, 1 ) != 1 || nsides < 0 ) return false;
    stl.putSolidText ( 80, text );
    ISTL::Facet facet;
    for ( int i = nsides; --i >= 0; )
    {
        if ( file.read ( &facet.norm   , 12, 1 ) != 1 ) return false;
        if ( file.read ( &facet.vert[0], 12, 1 ) != 1 ) return false;
        if ( file.read ( &facet.vert[1], 12, 1 ) != 1 ) return false;
        if ( file.read ( &facet.vert[2], 12, 1 ) != 1 ) return false;
        if ( file.read ( text, 2, 1 ) != 1 ) return false;
        stl.putFacet ( facet );
    }
	return true;
}

bool saveSTLB ( WriteFile & file, ISTL & stl )
{
    int ntext;
    char buf[80];
    const char * text = stl.getSolidText ( ntext );
    for ( int j = 0; j < 80; ++j )
    {
        buf[j] = j < ntext ? text[j] : 0;
    }
    if ( file.write ( buf, 80, 1 ) != 1 ) return false;
    int nfacet;
    const ISTL::Facet * facet = stl.getFacet ( nfacet );
    if ( file.write ( &nfacet, 4, 1 ) != 1 ) return false;
    buf[0] = buf[1] = 0;
    for ( int i = 0; i < nfacet; ++i )
    {
        const ISTL::Facet & f = facet[i];
        if ( file.write ( & f.norm, 12, 1 ) != 1 ) return false;
        if ( file.write ( f.vert+0, 12, 1 ) != 1 ) return false;
        if ( file.write ( f.vert+1, 12, 1 ) != 1 ) return false;
        if ( file.write ( f.vert+2, 12, 1 ) != 1 ) return false;
        if ( file.write ( buf, 2, 1 ) != 1 ) return false;
    }
	return true;
}

////////////////////////////////////////////////////////////////////////////////////

#include <vector>
#include "Vector3i.h"
#include "Poly3gon.h"

namespace {

class STL : public ISTL
{
    bool isSolid, isEnd;
    int nText;
    char text[80];
    std::vector<Facet> vfacet;
public:
    STL () : isSolid(false), isEnd(false), nText(0) {}
    virtual void putSolidText ( int n, const char * text );
    virtual void putFacet ( const Facet & facet );
    virtual const char * getSolidText ( int & n ) const;
    virtual const Facet * getFacet ( int & n ) const;
    virtual void clear ();
};

void STL::putSolidText ( int n, const char * t )
{
    if ( isSolid )
    {
        isEnd = true;
        return;
    }
    isSolid = true;
    if ( n < 0 ) n = 0; else
    if ( n > 80 ) n = 80;
    nText = n;
    for ( int i = n; --i >= 0; ) text[i] = t[i];
}

void STL::putFacet ( const Facet & facet )
{
    if ( isEnd ) return;
    vfacet.push_back ( facet );
}

const ISTL::Facet * STL::getFacet ( int & n ) const
{
    n = vfacet.size();
    return & vfacet[0];
}

const char * STL::getSolidText ( int & n ) const
{
    n = nText;
    return text;
}

void STL::clear ()
{
    nText = 0;
    isSolid = isEnd = false;
    vfacet.resize ( 0 );
}

struct Node
{
    int next, index;
};

class Vector3iHashTable
{
    std::vector<Vector3i> varr;
    std::vector<Node> iarr;
    int count;
public:
    Vector3iHashTable ();
    int index ( const Vector3i & v );
    const Vector3i * getData ( int & nv )
    {
        nv = varr.size();
        return nv > 0 ? &varr[0] : 0;
    }
};

Vector3iHashTable::Vector3iHashTable () : iarr(1024), count(1024)
{
    for ( int j = 0; j < 1024; ++j ) iarr[j].next = 0;
}
 
int Vector3iHashTable::index ( const Vector3i & v )
{
    unsigned char * p = (unsigned char *)& v;
    int s = p[0] + p[1] + p[2] + p[3] + p[4] + p[5] + p[6] + p[7] + p[8] + p[9] + p[10] + p[11];
    s &= 1023;
    for (;;)
    {
        const Node & node = iarr[s];
        if ( node.next == 0 ) break;
        if ( v == varr[node.index] ) return node.index;
        s = node.next;
    }
    Node & node = iarr[s];
    node.next = count++;
    const int i = node.index = varr.size();
    iarr.resize ( count );
    iarr[count-1].next = 0;
    varr.push_back ( v );
    return i;
}

void copy ( const STL & stl, Poly3gon<Vector3f> & poly )
{
    int nfacet;
    const STL::Facet * facet = stl.getFacet ( nfacet );
    poly.resize ( 0, nfacet );
    Vector3iHashTable table;
    for ( int i = 0; i < nfacet; ++i ) 
    {
        const Vector3i * v = (Vector3i*) facet[i].vert;
        Trigon & t = poly.side[i];
        t.a = table.index ( v[0] );
        t.b = table.index ( v[1] );
        t.c = table.index ( v[2] );
    }
    int nverts;
    const Vector3i * vert = table.getData ( nverts );
    if ( nverts )
    {
        poly.resize ( nverts, nfacet );
        Vector3i * vertex = (Vector3i*) poly.vertex;
        for ( int i = nverts; --i >= 0; ) vertex[i] = vert[i];
    }
}

bool loadSTL ( ReadFile & file, int & ntext, char * text, Poly3gon<Vector3f> & poly,
               bool (*func) ( ReadFile & file, ISTL & stl ) )
{
    STL stl;
    if ( ! func ( file, stl ) ) return false;
    const char * str = stl.getSolidText ( ntext );
    for ( int i = ntext; --i >= 0; ) text[i] = str[i];
    copy ( stl, poly );
    return true;
}

void copy ( const Poly3gon<Vector3f> & poly, STL & stl )
{
    ISTL::Facet facet;
    for ( int i = 0; i < poly.nsides; ++i ) 
    {
        const Trigon & t = poly.side[i];
        facet.vert[0] = poly.vertex[t.a];
        facet.vert[1] = poly.vertex[t.b];
        facet.vert[2] = poly.vertex[t.c];
        facet.norm = ( facet.vert[0] % facet.vert[1] + 
                       facet.vert[1] % facet.vert[2] +
                       facet.vert[2] % facet.vert[0] ).norm();
        stl.putFacet ( facet );
    }
}

} // namespace

ISTL * makeSTL() { return new STL; }

////////////////////////////////////////////////////////////////////////////////////

bool loadSTLA ( ReadFile & file, int & ntext, char * text, Poly3gon<Vector3f> & poly )
{
    return loadSTL ( file, ntext, text, poly, loadSTLA );
}

bool loadSTLB ( ReadFile & file, int & ntext, char * text, Poly3gon<Vector3f> & poly )
{
    return loadSTL ( file, ntext, text, poly, loadSTLB );
}

bool saveSTLA ( WriteFile & file, int ntext, const char * text, const Poly3gon<Vector3f> & poly, int prec )
{
    STL stl;
    stl.putSolidText ( ntext, text );
    copy ( poly, stl );
    return saveSTLA ( file, stl, prec ) ;
}

bool saveSTLB ( WriteFile & file, int ntext, const char * text, const Poly3gon<Vector3f> & poly )
{
    STL stl;
    stl.putSolidText ( ntext, text );
    copy ( poly, stl );
    return saveSTLB ( file, stl ) ;
}

////////////////////////////////////////////////////////////////////////////////////
