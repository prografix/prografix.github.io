
#ifndef POLY3GON_H
#define POLY3GON_H

class Trigon
{
public:
    int a, b, c; // ������ ������ 
};

template <class T> class Poly3gon
{
    Poly3gon ( Poly3gon & );
    Poly3gon & operator = ( const Poly3gon & );
public:
    int nverts, nsides;
    T * vertex;    // ������ ������
    Trigon * side; // ������ �������������

    Poly3gon ( int nv, int ns ) : nverts(nv>0?nv:0), nsides(ns>0?ns:0)
    {
        vertex = new T[nverts];
        side = new Trigon[nsides];
    }

    ~Poly3gon ()
    {
        delete[] side;
        delete[] vertex;
    }

    void resize ( int nv, int ns )
    {
        if ( ns != nsides )
        {
            delete[] side;
            nsides = ns > 0 ? ns : 0;
            side = new Trigon[nsides];
        }
        if ( nv != nverts )
        {
            delete[] vertex;
            nverts = nv > 0 ? nv : 0;
            vertex = new T[nverts];
        }
    }
};

template <class T> void swap ( Poly3gon<T> & p1, Poly3gon<T> & p2 )
{
    int nverts = p1.nverts;
    p1.nverts = p2.nverts;
    p2.nverts = nverts;

    int nsides = p1.nsides;
    p1.nsides = p2.nsides;
    p2.nsides = nsides;

    T * vertex = p1.vertex;
    p1.vertex = p2.vertex;
    p2.vertex = vertex;

    Trigon * side = p1.side;
    p1.side = p2.side;
    p2.side = side;
}

#endif
