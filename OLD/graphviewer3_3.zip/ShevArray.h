
#ifndef SHEVARRAY_H
#define SHEVARRAY_H

namespace Shev
{

template <class T> class Array
{
    int sz;
    T * data;
    Array ( Array& );
    void operator= ( const Array & );
public:
explicit Array ( int n ) : sz(n), data(new T[n]) {}
         Array ()        : sz(0), data(0) {}
        ~Array () { delete[] data; }
    const T & operator[] ( int i ) const { return data[i]; }
          T & operator[] ( int i )       { return data[i]; }
    int size () const { return sz; }
    void resize ( int n )
    {
        if ( n < 0 ) n = 0;
        delete[] data;
        data = new T[sz=n];
    }
    void resizeAndCopy ( int n )
    {
        if ( n < 0 ) n = 0;
        int k = n > sz ? sz : n;
        T * tmp = new T[sz=n];
        for ( int i = k; --i >= 0; ) tmp[i] = data[i];
        delete[] data;
        data = tmp;
    }
};

}

#endif
