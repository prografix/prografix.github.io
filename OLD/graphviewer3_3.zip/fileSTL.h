
#ifndef FILE_STL_H
#define FILE_STL_H

#include "Vector3f.h"

class ISTL
{
protected:
    virtual ~ISTL();
public:
    class Facet
    {
    public:
        Vector3f norm, vert[3];
    };
    virtual void putSolidText ( int n, const char * text ) = 0;
    virtual void putFacet ( const Facet & facet ) = 0;
    virtual const char * getSolidText ( int & n ) const = 0;
    virtual const Facet * getFacet ( int & n ) const = 0;
    virtual void clear () = 0;
};

ISTL * makeSTL();

class ReadFile;
class WriteFile;

bool loadSTLA ( ReadFile & file, ISTL & stl );
bool loadSTLB ( ReadFile & file, ISTL & stl );

bool saveSTLA ( WriteFile & file, ISTL & stl, int prec );
bool saveSTLB ( WriteFile & file, ISTL & stl );

template <class T> class Poly3gon;

bool loadSTLA ( ReadFile & file, int & ntext, char * text, Poly3gon<Vector3f> & poly );
bool loadSTLB ( ReadFile & file, int & ntext, char * text, Poly3gon<Vector3f> & poly );

bool saveSTLA ( WriteFile & file, int ntext, const char * text, const Poly3gon<Vector3f> & poly, int prec );
bool saveSTLB ( WriteFile & file, int ntext, const char * text, const Poly3gon<Vector3f> & poly );

#endif