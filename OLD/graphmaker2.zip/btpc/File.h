
class File
{
public:
    virtual int read(void * p, const int size, const int count) = 0;
    virtual int write(const void * p, const int size, const int count) = 0;
    virtual int seek(long offset, int origin) = 0;
    virtual long tell() = 0;
    virtual unsigned char getc() = 0;
    virtual void putc(unsigned char c) = 0;
    virtual void rewind() = 0;
    virtual void flush() = 0;
    virtual ~File() {}
};