// GraphMakerView.cpp : implementation of the CGraphMakerView class
//

#include "stdafx.h"
#include "math.h"
#include "gl\gl.h"
#include "GraphMaker.h"
#include "GraphMakerDoc.h"
#include "GraphMakerView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGraphMakerView

IMPLEMENT_DYNCREATE(CGraphMakerView, CView)

BEGIN_MESSAGE_MAP(CGraphMakerView, CView)
	//{{AFX_MSG_MAP(CGraphMakerView)
	ON_WM_SIZE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_CREATE()
	ON_WM_ERASEBKGND()
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGraphMakerView construction/destruction

static CGraphMakerView * view;

CGraphMakerView::CGraphMakerView()
{
	m_pDC = 0;
    view = this;
}

CGraphMakerView::~CGraphMakerView()
{
    delete m_pDC;
}

void SetTimer ( int uElapse )
{
    view->SetTimer ( 1, uElapse, 0 );
}

BOOL CGraphMakerView::PreCreateWindow(CREATESTRUCT& cs)
{
    cs.style |= WS_CLIPSIBLINGS | WS_CLIPCHILDREN;
	return CView::PreCreateWindow(cs);
}

int CGraphMakerView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1) return -1;
    m_pDC = new CClientDC(this);
    PIXELFORMATDESCRIPTOR pfd = 
	{
        sizeof(PIXELFORMATDESCRIPTOR),  // size of this pfd
        1,                              // version number
        PFD_DRAW_TO_WINDOW |            // support window
          PFD_SUPPORT_OPENGL |          // support OpenGL
          PFD_DOUBLEBUFFER,             // double buffered
        PFD_TYPE_RGBA,                  // RGBA type
        24,                             // 24-bit color depth
        0, 0, 0, 0, 0, 0,               // color bits ignored
        0,                              // 8-bit alpha buffer
        0,                              // shift bit ignored
        0,                              // no accumulation buffer
        0, 0, 0, 0,                     // accum bits ignored
        0,                              // 32-bit z-buffer
        0,                              // 8-bit stencil buffer
        0,                              // no auxiliary buffer
        PFD_MAIN_PLANE,                 // main layer
        0,                              // reserved
        0, 0, 0                         // layer masks ignored
    };
    int pixelformat;
    if ( (pixelformat = ChoosePixelFormat(m_pDC->GetSafeHdc(), &pfd)) == 0 )
    {
        MessageBox("ChoosePixelFormat failed");
        return -1;
    }
    if (SetPixelFormat(m_pDC->GetSafeHdc(), pixelformat, &pfd) == FALSE)
    {
        MessageBox("SetPixelFormat failed");
        return -1;
    }
    int n = ::GetPixelFormat(m_pDC->GetSafeHdc());
    ::DescribePixelFormat(m_pDC->GetSafeHdc(), n, sizeof(pfd), &pfd);
    m_hrc = wglCreateContext(m_pDC->GetSafeHdc());
	if ( wglMakeCurrent ( m_pDC->GetSafeHdc(), m_hrc ) == FALSE ) return -1;
	return 0;
}


/////////////////////////////////////////////////////////////////////////////
// CGraphMakerView drawing

void CGraphMakerView::OnDraw(CDC* pDC)
{
	CGraphMakerDoc* pDoc = GetDocument();
    pDoc->draw();
    glFlush();
    SwapBuffers(wglGetCurrentDC());
}

/////////////////////////////////////////////////////////////////////////////
// CGraphMakerView printing

BOOL CGraphMakerView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CGraphMakerView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CGraphMakerView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CGraphMakerView diagnostics

#ifdef _DEBUG
void CGraphMakerView::AssertValid() const
{
	CView::AssertValid();
}

void CGraphMakerView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CGraphMakerDoc* CGraphMakerView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGraphMakerDoc)));
	return (CGraphMakerDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGraphMakerView message handlers

BOOL CGraphMakerView::OnEraseBkgnd(CDC* pDC) 
{
	return TRUE;
}

void CGraphMakerView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
    if ( cy > 0 && cx > 0 )
    {
        glViewport(0, 0, cx, cy);
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        double dy = 1.;
        double dx = double(cx)/cy;
        glOrtho(-dx, dx, -dy, dy, -10., 10.);
//        double buf[16];
//        glGetDoublev(GL_PROJECTION_MATRIX, buf);
//        glFrustum(-1, 1, -1, 1, 3., 4.);
//        glTranslated(0.,0.,-2);
        glMatrixMode(GL_MODELVIEW);
    }	
}

void CGraphMakerView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	m_point = point;
    button_is_down = true;
	CView::OnLButtonDown(nFlags, point);
}

void CGraphMakerView::OnLButtonUp(UINT nFlags, CPoint point) 
{
	button_is_down = false;
	CView::OnLButtonUp(nFlags, point);
}

void CGraphMakerView::OnMouseMove(UINT nFlags, CPoint point) 
{
	if ( button_is_down && ( nFlags & MK_LBUTTON ) && point != m_point )
    {
    	double x = point.x - m_point.x;
	    double y = point.y - m_point.y;
        m_point = point;
        glMatrixMode ( GL_MODELVIEW );
        double data[16];
        glGetDoublev ( GL_MODELVIEW_MATRIX, data );
        glLoadIdentity ();
        double t = sqrt(x*x+y*y);
        glRotated ( t, y/t, x/t, 0. );
        glMultMatrixd ( data );
        Invalidate(TRUE);
    }
	CView::OnMouseMove(nFlags, point);
}

void CGraphMakerView::OnTimer(UINT nIDEvent) 
{
	Invalidate(TRUE);
	CView::OnTimer(nIDEvent);
}
