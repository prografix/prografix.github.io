// GraphMakerDoc.cpp : implementation of the CGraphMakerDoc class
//

#include "stdafx.h"
#include "GraphMaker.h"
#include "GraphMakerDoc.h"
#include "GraphicInterface.h"
#include "GIStorage.h"
#include "GLDevice.h"
#include "FileWriter.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGraphMakerDoc

IMPLEMENT_DYNCREATE(CGraphMakerDoc, CDocument)

BEGIN_MESSAGE_MAP(CGraphMakerDoc, CDocument)
	//{{AFX_MSG_MAP(CGraphMakerDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGraphMakerDoc construction/destruction

void drawCow ( GraphicInterface & gi );
void drawDiamond ( GraphicInterface & gi );
void drawBounceBall ( GraphicInterface & gi );
void idea ( GraphicInterface & gi );

CGraphMakerDoc::CGraphMakerDoc()
{
	data = new GIStorage;

//    drawCow ( *data );
//    char * comment = "13 July 2002. A. D. Shevchenko created this file from Scott R. Nelson data.";
//    FileWriter file ( "Cow.gra", comment );

    drawBounceBall ( *data );
    char * comment = "13 July 2002. A. D. Shevchenko created this file. The original idea was from a similar program by Andreas Gustafsson.";
    FileWriter file ( "BounceBall.gra", comment );

//    idea ( *data );
//    char * comment = "21 June 2002. A. D. Shevchenko created this file. The original idea was from a similar program by Mark J. Kilgard ( SGI ).";
//    FileWriter file ( "Idea.gra", comment );

//    drawDiamond ( *data );
//    char * comment = "21 June 2002. A. D. Shevchenko created this file.";
//    FileWriter file ( "Diamond.gra", comment );

    *data >> file;
}

CGraphMakerDoc::~CGraphMakerDoc()
{
    delete data;
}

BOOL CGraphMakerDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CGraphMakerDoc serialization

void CGraphMakerDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CGraphMakerDoc diagnostics

#ifdef _DEBUG
void CGraphMakerDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CGraphMakerDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGraphMakerDoc commands

void CGraphMakerDoc::draw()
{
    static GLDevice device;
    *data >> device;
}