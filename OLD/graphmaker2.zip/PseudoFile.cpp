#include "btpc/File.h"
#include "ShevArray.h"
#include "PseudoFile.h"

PseudoFile::PseudoFile ( Shev::Array<unsigned char> & p ) : buf(p), pos(0)
{
    if ( buf.size() < 1 ) buf.resize ( 512 );
}

unsigned char PseudoFile::getc()
{
    return pos + 1 < buf.size() ? buf[pos++] : buf[pos];
}

void PseudoFile::putc(unsigned char c)
{
    while ( pos >= buf.size() ) buf.resizeAndCopy ( 2*buf.size() );
    buf[pos++] = c;
}

int PseudoFile::seek(long offset, int origin)
{
    if ( origin == 1 )
    {
        offset += pos;
    }
    else
    if ( origin == 2 )
    {
        offset = buf.size() - 1 - offset;
    }
    if ( offset < 0 || offset >= buf.size() ) return 1;
    pos = offset;
    return 0;
}

int PseudoFile::read(void * ptr, const int size, const int count)
{
    if ( size <= 0 || count <= 0 ) return 0;
    int m = ( buf.size() - 1 - pos ) / size;
    if ( m <= 0 ) return 0;
    if ( m > count ) m = count;
    const int n = size * m;
    unsigned char * p = (unsigned char *) ptr;
    for ( int i = 0; i < n; ++i )
    {
        p[i] = buf[pos++];
    }
    return m;
}

int PseudoFile::write(const void * ptr, const int size, const int count)
{
    if ( size <= 0 || count <= 0 ) return 0;
    const int n = size * count;
    while ( buf.size() - 1 - pos < n ) buf.resizeAndCopy ( 2*buf.size() );
    const unsigned char * p = (const unsigned char *) ptr;
    for ( int i = 0; i < n; ++i )
    {
        buf[pos++] = p[i];
    }
    return count;
}
