
class PseudoFile : public File
{
    Shev::Array<unsigned char> & buf;
    int pos;
public:
    PseudoFile ( Shev::Array<unsigned char> & p );
    int read(void * p, const int size, const int count);
    int write(const void * p, const int size, const int count);
    int seek(long offset, int origin);
    long tell() { return pos; }
    unsigned char getc();
    void putc(unsigned char c);
    void rewind () { pos = 0; }
    void flush() {}
};