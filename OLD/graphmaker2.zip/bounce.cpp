
#include "stdafx.h"
#include "math.h"
#include "io.h"
#include "fcntl.h"
#include "GraphicInterface.h"
#include "btpc/File.h"
#include "ShevArray.h"
#include "PseudoFile.h"
#include "btpc/btpc.h"

BITMAPINFO * loadBMP ( const char * fileName, unsigned char * & map )
{
	const int h = _open ( fileName, _O_RDONLY | _O_BINARY );
	if ( h == -1 )
	{
		map = 0;
		return 0;
	}
	BITMAPFILEHEADER bmfh;
	_read(h, &bmfh, sizeof(BITMAPFILEHEADER));
	if ( bmfh.bfType != 0x4d42 )
	{
		_close(h);
		map = 0;
		return 0;
	}
	BITMAPINFOHEADER bmih;
	_read(h, &bmih, sizeof(BITMAPINFOHEADER));
	int n = bmih.biBitCount > 16 ? 0 : (1<<bmih.biBitCount) * sizeof(RGBQUAD);
	BITMAPINFO * bmi = ( BITMAPINFO * ) new char[sizeof(BITMAPINFOHEADER)+n];
	bmi->bmiHeader.biSize = bmih.biSize;
	bmi->bmiHeader.biWidth = bmih.biWidth;
	if(bmih.biWidth%4)
    {
		bmi->bmiHeader.biWidth += (4-bmih.biWidth%4); 
	}
	bmi->bmiHeader.biHeight = bmih.biHeight;
	bmi->bmiHeader.biPlanes = bmih.biPlanes;
	bmi->bmiHeader.biBitCount = bmih.biBitCount;
	bmi->bmiHeader.biCompression = bmih.biCompression;
	bmi->bmiHeader.biSizeImage = bmih.biSizeImage;
	bmi->bmiHeader.biXPelsPerMeter = bmih.biXPelsPerMeter;
	bmi->bmiHeader.biYPelsPerMeter = bmih.biYPelsPerMeter;
	bmi->bmiHeader.biClrUsed = bmih.biClrUsed;
	bmi->bmiHeader.biClrImportant = bmih.biClrImportant;
	if(n) _read(h, bmi->bmiColors, n);
	n = bmfh.bfSize - bmfh.bfOffBits;
	map = new unsigned char[n];
	_read(h, map, n);
	_close(h);
    return bmi;
}

bool loadBitmap ( const char * filename, int & width, int & height, unsigned char * & pData )
{
	BITMAPINFO * bmi = loadBMP ( filename, pData );
    if ( bmi )
    {
	    width = bmi->bmiHeader.biWidth;
	    height = bmi->bmiHeader.biHeight;
        delete bmi;
        return true;
    }
    return false;
}

void build2DMipmapsBGR_BTPC ( GraphicInterface & gi, int width, int height,
                              const unsigned char * pData, int quality )
{
    Shev::Array<unsigned char> arr(3*width*height);
    PseudoFile pf ( arr );
    if ( cbtpc ( width, height, pData, 3, 255, quality, pf ) )
    {
        gi.Build2DMipmapsBGR_BTPC ( pf.tell(), & arr[0] );
    }
}

void drawBounceBall ( GraphicInterface & gi )
{
    enum intIndex
    {
        floorTex, ballTex, reflectTex, int_temp
    };
    enum floatIndex
    {
        xSize, ySize, zSize,
        xShift, yShift, zShift,
        angle, axisX, axisY, axisZ,
        temp, ballY, perspective,
        viewport = perspective + 4,
    };
    {
        gi.IntAstDC ( floorTex, floorTex );
        gi.IntAstDC ( ballTex, ballTex );
        gi.IntAstDC ( reflectTex, reflectTex );

        gi.GenTextures(3, floorTex);
        unsigned char * pData = 0;
        int width, height;
        loadBitmap("floor.bmp", width, height, pData);
        if (pData)
        {
	        gi.BindTexture2D(floorTex);
	        gi.TexParameter2DMinFilterLinearMipmapNearest();
            build2DMipmapsBGR_BTPC ( gi, width, height, pData, 85 );
            delete[] pData;
        }
        loadBitmap("ball.bmp", width, height, pData);
        if (pData)
        {
	        gi.BindTexture2D(ballTex);
	        gi.TexParameter2DMinFilterLinearMipmapNearest();
            build2DMipmapsBGR_BTPC ( gi, width, height, pData, 85 );
            delete[] pData;
        }
        loadBitmap("reflection.bmp", width, height, pData);
        if (pData)
        {
	        gi.BindTexture2D(reflectTex);
	        gi.TexParameter2DMinFilterLinearMipmapNearest();
            build2DMipmapsBGR_BTPC ( gi, width, height, pData, 85 );
            delete[] pData;
        }
	    gi.EnableTexture2D();
        gi.EnableDepthTest();                 // Enable Depth Buffer
	    gi.QuadricTexture(true); 
        gi.BlendFunc(BFP_SRC_ALPHA, BFP_ONE);

        gi.FloatAstDC ( xShift, 0 );
        gi.FloatAstDC ( zShift, 0 );
        gi.FloatAstDC ( angle, 0 );
        gi.FloatAstDC ( axisX, 0 );
        gi.FloatAstDC ( axisY, 1 );
        gi.FloatAstDC ( axisZ, 0 );
        gi.FloatAstDC ( perspective  , 45 );
        gi.FloatAstDC ( perspective+2,  1 );
        gi.FloatAstDC ( perspective+3, 10 );

    }

    gi.SetTimer(10);
    gi.NextStart();

    gi.Clock ( int_temp );
    gi.IntDivDC ( int_temp, 80 );
    gi.FloatAstFromInt ( angle, int_temp );

    gi.MatrixModeProjection();
    gi.LoadIdentity();
    gi.GetFloatViewport(viewport);
    gi.FloatDivDD(viewport+2, viewport+3);
    gi.FloatAstDD(perspective+1, viewport+2);
    gi.Perspective4v(perspective);

    gi.MatrixModeModelView();
    gi.LoadIdentity();
    gi.Translate ( 0.0f, -0.3f, -2.5f );
    gi.Rotate ( 25.f, 1.0f, 0.0f, 0.0f );
    gi.Rotate4v ( angle );

    // Calculate the balls position
    gi.FloatAstDC ( ySize, 1 );
    gi.FloatAstDD ( ballY, angle );
    gi.FloatDivDC ( ballY, 16 );
    gi.FloatSin ( ballY );
    gi.FloatMulDC ( ballY, 0.9f );
    gi.FloatAbs ( ballY );
    gi.IfFloatDC ( ballY, LT, 0.3f );
    {
        gi.FloatAstDC ( temp, 1.3f );
        gi.FloatSubDD ( temp, ballY );
        gi.FloatDivDD ( ySize, temp );
    }
    gi.EndIf();

    gi.FloatAstDC ( zSize, 2 );       // floatValue[zSize] = 2;
    gi.FloatSubDD ( zSize, ySize );   // floatValue[zSize] -= floatValue[ySize];
    gi.FloatAstDD ( xSize, zSize );   // floatValue[xSize] = floatValue[zSize];
    gi.FloatAstDC ( yShift, 0.1f );   // 
    gi.FloatAddDD ( yShift, ballY );  // 
/*
	gi.ClearStencilBuffer();
	gi.EnableStencilTest();
	gi.StencilFuncAlways(1, 0xFF);
	gi.StencilOp(SOP_KEEP, SOP_REPLACE, SOP_REPLACE);
    gi.Color(0.f, 0.f, 0.f);
    gi.BeginQuads();
    gi.Vertex (-1.0f,  0.0f,  1.0f );
    gi.Vertex ( 1.0f,  0.0f,  1.0f );
    gi.Vertex ( 1.0f,  0.0f, -1.0f );
    gi.Vertex (-1.0f,  0.0f, -1.0f );
    gi.End();
	gi.StencilFuncEqual(1, 0xFF);
	gi.StencilOp(SOP_KEEP, SOP_KEEP, SOP_KEEP);*/
    gi.ClearColorBuffer();
    gi.ClearDepthBuffer();

  //-----  Draw the Reflection of the Ball  -----//
  // Draw the ball using standard textures
    gi.PushMatrix();
    gi.Scale3v(xSize); // squash the ball into shape
    gi.DisableBlend();
    gi.BindTexture2D(ballTex);
    gi.Color(0.4f,0.4f,0.4f);
    gi.FloatMulDC(yShift, -1);
    gi.Translate3v(xShift);
    gi.FloatMulDC(yShift, -1);
    gi.Sphere(0.3f, 24, 24);
  // Draw a sphere of the environment
    gi.EnableBlend();
    gi.DepthFuncLEqual();
    gi.BindTexture2D(reflectTex);
    gi.Sphere(0.3f, 24, 24);
    gi.PopMatrix();
//	gi.DisableStencilTest();

  //-----  Draw the Floor  -----//
    gi.EnableBlend();
    gi.DepthFuncLess();
    gi.Color(0.7f, 0.8f, 0.8f, 0.8f);
    gi.BindTexture2D(floorTex);
    gi.BeginQuads();
    gi.TexCoord2 ( 0.0f, 0.0f );   gi.Vertex (-1.0f,  0.0f,  1.0f );
    gi.TexCoord2 ( 1.0f, 0.0f );   gi.Vertex ( 1.0f,  0.0f,  1.0f );
    gi.TexCoord2 ( 1.0f, 1.0f );   gi.Vertex ( 1.0f,  0.0f, -1.0f );
    gi.TexCoord2 ( 0.0f, 1.0f );   gi.Vertex (-1.0f,  0.0f, -1.0f );
    gi.End();

  //-----  Draw the Main Ball  -----//
  // Draw the ball using standard textures
    gi.PushMatrix();
    gi.Scale3v(xSize); // squash the ball into shape
    gi.DisableBlend();
    gi.BindTexture2D(ballTex);
    gi.Color(1.f,1.f,1.f);
    gi.Translate3v(xShift);
    gi.Sphere(0.3f, 32, 32);
  // Draw a sphere of the environment
    gi.EnableBlend();
    gi.DepthFuncLEqual();
    gi.BindTexture2D(reflectTex);
    gi.Sphere(0.3f, 32, 32);
    gi.PopMatrix();
}