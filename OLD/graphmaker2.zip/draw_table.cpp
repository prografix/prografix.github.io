
#include "GraphicInterface.h"

static void draw_a ( GraphicInterface & gi )
{
    gi.BeginTriangleStrip();
	gi.Vertex(5.618949f, 10.261048f);
	gi.Vertex(5.322348f, 9.438848f);
	gi.Vertex(5.124614f, 10.030832f);
	gi.Vertex(4.860968f, 9.488181f);
	gi.Vertex(4.811534f, 9.932169f);
	gi.Vertex(3.938208f, 9.438848f);
	gi.Vertex(3.658084f, 9.685509f);
	gi.Vertex(2.784758f, 8.994862f);
	gi.Vertex(2.801236f, 9.175745f);
	gi.Vertex(1.960865f, 8.172662f);
	gi.Vertex(1.186406f, 7.761562f);
	gi.Vertex(1.252317f, 6.561151f);
	gi.Vertex(0.576725f, 6.610483f);
	gi.Vertex(0.939238f, 5.525180f);
	gi.Vertex(0.164779f, 4.883864f);
	gi.Vertex(0.840371f, 4.818089f);
	gi.Vertex(0.230690f, 3.963001f);
	gi.Vertex(0.939238f, 4.242549f);
	gi.Vertex(0.609681f, 3.255909f);
	gi.Vertex(1.268795f, 3.963001f);
	gi.Vertex(1.021627f, 3.075026f);
	gi.Vertex(1.861998f, 4.045221f);
	gi.Vertex(1.829042f, 3.535457f);
	gi.Vertex(2.817714f, 4.818089f);
	gi.Vertex(3.163749f, 4.998972f);
	gi.Vertex(3.971164f, 6.643371f);
	gi.Vertex(4.267765f, 6.725591f);
	gi.Vertex(4.663234f, 7.630010f);
    gi.End();

    gi.BeginTriangleStrip();
	gi.Vertex(5.404737f, 9.734840f);
	gi.Vertex(4.646756f, 9.669065f);
	gi.Vertex(5.108136f, 8.731757f);
	gi.Vertex(4.679712f, 8.600205f);
	gi.Vertex(4.926879f, 7.564234f);
	gi.Vertex(4.366632f, 6.692703f);
	gi.Vertex(4.663234f, 5.344296f);
	gi.Vertex(3.888774f, 4.850976f);
	gi.Vertex(4.630278f, 4.094553f);
	gi.Vertex(3.954686f, 3.963001f);
	gi.Vertex(4.828012f, 3.798561f);
	gi.Vertex(4.168898f, 3.321686f);
	gi.Vertex(5.157569f, 3.864337f);
	gi.Vertex(4.514933f, 3.091470f);
	gi.Vertex(5.553038f, 4.045221f);
	gi.Vertex(5.305870f, 3.634121f);
	gi.Vertex(5.932029f, 4.176773f);
    gi.End();
}

static void draw_d ( GraphicInterface & gi )
{
    gi.BeginTriangleStrip();
	gi.Vertex(4.714579f, 9.987679f);
	gi.Vertex(2.841889f, 9.429158f);
	gi.Vertex(2.825462f, 9.166325f);
	gi.Vertex(1.856263f, 8.722793f);
	gi.Vertex(2.004107f, 8.000000f);
	gi.Vertex(0.969199f, 7.605750f);
	gi.Vertex(1.494866f, 6.636550f);
	gi.Vertex(0.607803f, 6.028748f);
	gi.Vertex(1.527721f, 4.960986f);
	gi.Vertex(0.772074f, 4.254620f);
	gi.Vertex(1.774127f, 4.139630f);
	gi.Vertex(1.445585f, 3.186858f);
	gi.Vertex(2.266940f, 3.843942f);
	gi.Vertex(2.250513f, 3.022587f);
	gi.Vertex(2.776181f, 3.843942f);
	gi.Vertex(3.137577f, 3.383984f);
	gi.Vertex(3.351129f, 4.008214f);
	gi.Vertex(3.909651f, 4.451746f);
	gi.Vertex(4.090349f, 4.960986f);
	gi.Vertex(4.862423f, 5.946612f);
	gi.Vertex(4.763860f, 6.652977f);
	gi.Vertex(5.388090f, 7.572895f);
	gi.Vertex(4.862423f, 8.492813f);
	gi.Vertex(5.618070f, 9.921971f);
	gi.Vertex(4.698152f, 10.940452f);
	gi.Vertex(5.338809f, 12.303902f);
	gi.Vertex(4.238193f, 12.960985f);
	gi.Vertex(4.451746f, 14.554415f);
	gi.Vertex(3.581109f, 14.291581f);
	gi.Vertex(3.613963f, 15.342916f);
	gi.Vertex(2.677618f, 15.145790f);
	gi.Vertex(2.480493f, 15.540041f);
	gi.Vertex(2.036961f, 15.211499f);
	gi.Vertex(1.281314f, 15.112936f);
    gi.End();
}

static void draw_e ( GraphicInterface & gi )
{
    gi.BeginTriangleStrip();
	gi.Vertex(1.095436f, 6.190871f);
	gi.Vertex(2.107884f, 6.970954f);
	gi.Vertex(2.556017f, 7.020747f);
	gi.Vertex(3.020747f, 7.867220f);
	gi.Vertex(3.518672f, 8.033195f);
	gi.Vertex(3.269710f, 8.531120f);
	gi.Vertex(4.165975f, 8.929461f);
	gi.Vertex(3.302905f, 9.062241f);
	gi.Vertex(4.331950f, 9.626556f);
	gi.Vertex(3.286307f, 9.344398f);
	gi.Vertex(4.116183f, 9.958507f);
	gi.Vertex(3.004149f, 9.510373f);
	gi.Vertex(3.518672f, 9.991701f);
	gi.Vertex(2.705394f, 9.493776f);
	gi.Vertex(2.091286f, 9.311203f);
	gi.Vertex(2.041494f, 9.062241f);
	gi.Vertex(1.178423f, 8.514523f);
	gi.Vertex(1.443983f, 8.165976f);
	gi.Vertex(0.481328f, 7.535270f);
	gi.Vertex(1.045643f, 6.904564f);
	gi.Vertex(0.149378f, 6.091286f);
	gi.Vertex(1.095436f, 5.410789f);
	gi.Vertex(0.464730f, 4.232365f);
	gi.Vertex(1.377593f, 4.497925f);
	gi.Vertex(1.261411f, 3.136930f);
	gi.Vertex(1.925311f, 3.950207f);
	gi.Vertex(2.240664f, 3.037344f);
	gi.Vertex(2.589212f, 3.834025f);
	gi.Vertex(3.087137f, 3.269710f);
	gi.Vertex(3.236515f, 3.867220f);
	gi.Vertex(3.684647f, 3.867220f);
	gi.Vertex(3.867220f, 4.448133f);
	gi.Vertex(4.398340f, 5.128631f);
    gi.End();
}

static void draw_i ( GraphicInterface & gi )
{
    gi.BeginTriangleStrip();
	gi.Vertex(0.548767f, 9.414791f);
	gi.Vertex(2.795284f, 9.757771f);
	gi.Vertex(1.457663f, 9.311897f);
	gi.Vertex(2.503751f, 9.157557f);
	gi.Vertex(1.714898f, 8.986067f);
	gi.Vertex(2.109325f, 7.785638f);
	gi.Vertex(1.286174f, 7.013934f);
	gi.Vertex(1.800643f, 6.070740f);
	gi.Vertex(0.994641f, 5.161843f);
	gi.Vertex(1.783494f, 4.767417f);
	gi.Vertex(0.943194f, 4.167202f);
	gi.Vertex(1.852090f, 4.304394f);
	gi.Vertex(1.063237f, 3.549839f);
	gi.Vertex(2.023580f, 3.978564f);
	gi.Vertex(1.406217f, 3.172562f);
	gi.Vertex(2.315113f, 3.875670f);
	gi.Vertex(2.006431f, 3.018221f);
	gi.Vertex(2.812433f, 3.944266f);
	gi.Vertex(2.726688f, 3.429796f);
	gi.Vertex(3.258307f, 4.132905f);
    gi.End();

    gi.BeginTriangleStrip();
	gi.Vertex(1.989282f, 10.923902f);
	gi.Vertex(2.778135f, 12.295820f);
	gi.Vertex(2.966774f, 11.678456f);
	gi.Vertex(3.687031f, 12.947481f);
    gi.End();
}

static void draw_m ( GraphicInterface & gi )
{
    gi.BeginTriangleStrip();
	gi.Vertex(0.590769f, 9.449335f);
	gi.Vertex(2.116923f, 9.842375f);
	gi.Vertex(1.362051f, 9.383828f);
	gi.Vertex(2.527179f, 9.825998f);
	gi.Vertex(1.591795f, 9.072672f);
	gi.Vertex(2.789744f, 9.514841f);
	gi.Vertex(1.690256f, 8.663255f);
	gi.Vertex(2.658462f, 8.335722f);
	gi.Vertex(1.575385f, 7.222108f);
	gi.Vertex(2.067692f, 6.255886f);
	gi.Vertex(0.918974f, 4.028659f);
	gi.Vertex(1.050256f, 3.013306f);
	gi.Vertex(0.705641f, 3.013306f);
    gi.End();

    gi.BeginTriangleStrip();
	gi.Vertex(2.018461f, 6.386899f);
	gi.Vertex(1.788718f, 5.617196f);
	gi.Vertex(2.921026f, 7.991812f);
	gi.Vertex(3.167180f, 8.008188f);
	gi.Vertex(3.544615f, 8.827022f);
	gi.Vertex(3.872821f, 8.843398f);
	gi.Vertex(4.414359f, 9.547595f);
	gi.Vertex(4.447179f, 9.056294f);
	gi.Vertex(5.120000f, 9.891504f);
	gi.Vertex(4.841026f, 8.843398f);
	gi.Vertex(5.825641f, 9.809621f);
	gi.Vertex(5.005128f, 8.040941f);
	gi.Vertex(5.989744f, 8.761515f);
	gi.Vertex(4.906667f, 6.714432f);
	gi.Vertex(5.595897f, 7.123848f);
	gi.Vertex(3.987692f, 2.996929f);
	gi.Vertex(4.348718f, 2.996929f);
    gi.End();

    gi.BeginTriangleStrip();
	gi.Vertex(5.218462f, 5.977482f);
	gi.Vertex(5.251282f, 6.354146f);
	gi.Vertex(6.449231f, 7.893552f);
	gi.Vertex(6.400000f, 8.221085f);
	gi.Vertex(7.302564f, 8.843398f);
	gi.Vertex(7.351795f, 9.334698f);
	gi.Vertex(7.827693f, 9.154554f);
	gi.Vertex(8.008205f, 9.842375f);
	gi.Vertex(8.139487f, 9.121801f);
	gi.Vertex(8.795897f, 9.973388f);
	gi.Vertex(8.402051f, 8.728762f);
	gi.Vertex(9.337436f, 9.531218f);
	gi.Vertex(8.402051f, 8.040941f);
	gi.Vertex(9.288205f, 8.433982f);
	gi.Vertex(7.745641f, 5.813715f);
	gi.Vertex(8.320000f, 5.928352f);
	gi.Vertex(7.286154f, 4.012282f);
	gi.Vertex(7.991795f, 4.126919f);
	gi.Vertex(7.499487f, 3.357216f);
	gi.Vertex(8.533334f, 3.766633f);
	gi.Vertex(8.123077f, 3.062436f);
	gi.Vertex(8.927179f, 3.832139f);
	gi.Vertex(8.910769f, 3.340839f);
	gi.Vertex(9.550769f, 4.126919f);
    gi.End();

}

static void draw_n ( GraphicInterface & gi )
{
    gi.BeginTriangleStrip();
	gi.Vertex(1.009307f, 9.444788f);
	gi.Vertex(2.548087f, 9.742002f);
	gi.Vertex(1.737332f, 9.213622f);
	gi.Vertex(2.994829f, 9.659443f);
	gi.Vertex(1.985522f, 8.751290f);
	gi.Vertex(3.127198f, 9.180598f);
	gi.Vertex(1.935884f, 7.975232f);
	gi.Vertex(2.481903f, 6.571723f);
	gi.Vertex(1.472596f, 5.019608f);
	gi.Vertex(1.439504f, 2.988648f);
	gi.Vertex(1.025853f, 2.988648f);
    gi.End();

    gi.BeginTriangleStrip();
	gi.Vertex(2.283350f, 6.059855f);
	gi.Vertex(2.035160f, 5.366357f);
	gi.Vertex(3.292658f, 7.711042f);
	gi.Vertex(3.540848f, 7.744066f);
	gi.Vertex(4.384695f, 9.031992f);
	gi.Vertex(4.699069f, 8.916409f);
	gi.Vertex(5.609100f, 9.808049f);
	gi.Vertex(5.145812f, 8.982456f);
	gi.Vertex(6.155119f, 9.791537f);
	gi.Vertex(5.410548f, 8.635707f);
	gi.Vertex(6.337125f, 9.312694f);
	gi.Vertex(5.360910f, 7.991744f);
	gi.Vertex(6.088935f, 8.090816f);
	gi.Vertex(4.947259f, 5.977296f);
	gi.Vertex(5.261634f, 4.804954f);
	gi.Vertex(4.616339f, 4.028896f);
	gi.Vertex(5.211996f, 3.962848f);
	gi.Vertex(4.732162f, 3.318886f);
	gi.Vertex(5.559462f, 3.814241f);
	gi.Vertex(5.228542f, 3.038184f);
	gi.Vertex(5.940021f, 3.814241f);
	gi.Vertex(5.906929f, 3.335397f);
	gi.Vertex(6.684591f, 4.094943f);
    gi.End();
}

static void draw_o ( GraphicInterface & gi )
{
    gi.BeginTriangleStrip();
	gi.Vertex(2.975610f, 9.603255f);
	gi.Vertex(2.878049f, 9.342828f);
	gi.Vertex(2.292683f, 9.131231f);
	gi.Vertex(2.048780f, 8.691760f);
	gi.Vertex(1.707317f, 8.528993f);
	gi.Vertex(1.658537f, 7.731434f);
	gi.Vertex(0.878049f, 7.047813f);
	gi.Vertex(1.349594f, 5.550356f);
	gi.Vertex(0.569106f, 5.029501f);
	gi.Vertex(1.528455f, 4.443540f);
	gi.Vertex(0.991870f, 3.434385f);
	gi.Vertex(1.967480f, 3.955239f);
	gi.Vertex(1.772358f, 2.994914f);
	gi.Vertex(2.422764f, 3.825025f);
	gi.Vertex(2.829268f, 3.092574f);
	gi.Vertex(3.154472f, 3.971516f);
	gi.Vertex(3.512195f, 3.727365f);
	gi.Vertex(3.772358f, 4.264496f);
	gi.Vertex(4.130081f, 4.524924f);
	gi.Vertex(4.162601f, 4.996948f);
	gi.Vertex(4.699187f, 5.403866f);
	gi.Vertex(4.471545f, 6.461852f);
	gi.Vertex(5.219512f, 7.243133f);
	gi.Vertex(4.439024f, 8.105799f);
	gi.Vertex(5.235772f, 8.756866f);
	gi.Vertex(4.065041f, 8.870804f);
	gi.Vertex(4.991870f, 9.391658f);
	gi.Vertex(3.853658f, 9.228891f);
	gi.Vertex(4.390244f, 9.912513f);
	gi.Vertex(3.463415f, 9.407935f);
	gi.Vertex(3.674797f, 9.912513f);
	gi.Vertex(2.829268f, 9.342828f);
	gi.Vertex(2.959350f, 9.603255f);
    gi.End();
}

static void draw_s ( GraphicInterface & gi )
{
    gi.BeginTriangleStrip();
	gi.Vertex(0.860393f, 5.283798f);
	gi.Vertex(0.529473f, 3.550052f);
	gi.Vertex(0.992761f, 4.491228f);
	gi.Vertex(0.910031f, 3.368421f);
	gi.Vertex(1.240951f, 3.830753f);
	gi.Vertex(1.456050f, 3.104231f);
	gi.Vertex(1.935884f, 3.517028f);
	gi.Vertex(2.002068f, 2.988648f);
	gi.Vertex(2.763185f, 3.533540f);
	gi.Vertex(3.061013f, 3.120743f);
	gi.Vertex(3.391934f, 3.748194f);
	gi.Vertex(4.053774f, 3.632611f);
	gi.Vertex(3.822130f, 4.540764f);
	gi.Vertex(4.550155f, 4.590299f);
	gi.Vertex(3.656670f, 5.465428f);
	gi.Vertex(4.517063f, 5.713106f);
	gi.Vertex(3.276112f, 5.894737f);
	gi.Vertex(3.921407f, 6.538700f);
	gi.Vertex(2.299896f, 6.736842f);
	gi.Vertex(3.044467f, 7.430341f);
	gi.Vertex(1.886246f, 7.496388f);
	gi.Vertex(2.581179f, 8.222910f);
	gi.Vertex(1.902792f, 8.751290f);
	gi.Vertex(2.680455f, 8.883385f);
	gi.Vertex(2.283350f, 9.312694f);
	gi.Vertex(3.358842f, 9.609907f);
	gi.Vertex(3.507756f, 9.907121f);
	gi.Vertex(4.285419f, 9.758514f);
	gi.Vertex(5.112720f, 9.973168f);
	gi.Vertex(4.748707f, 9.593395f);
    gi.End();
}

static void draw_t ( GraphicInterface & gi )
{
    gi.BeginTriangleStrip();
	gi.Vertex(2.986667f, 14.034801f);
	gi.Vertex(2.445128f, 10.088024f);
	gi.Vertex(1.788718f, 9.236438f);
	gi.Vertex(2.264615f, 7.664279f);
	gi.Vertex(1.165128f, 5.666326f);
	gi.Vertex(2.034872f, 4.945752f);
	gi.Vertex(1.132308f, 3.766633f);
	gi.Vertex(2.182564f, 3.570113f);
	gi.Vertex(1.411282f, 2.309109f);
	gi.Vertex(2.510769f, 2.341863f);
	gi.Vertex(2.149744f, 1.048106f);
	gi.Vertex(3.364103f, 1.375640f);
	gi.Vertex(3.167180f, 0.327533f);
	gi.Vertex(4.381538f, 0.736950f);
	gi.Vertex(5.005128f, 0.032753f);
	gi.Vertex(5.612308f, 0.638690f);
	gi.Vertex(6.235898f, 0.540430f);
	gi.Vertex(7.187692f, 1.162743f);
    gi.End();

    gi.BeginTriangleStrip();
	gi.Vertex(1.985641f, 9.039918f);
	gi.Vertex(2.133333f, 10.186285f);
	gi.Vertex(1.509744f, 9.023541f);
	gi.Vertex(1.608205f, 9.662231f);
	gi.Vertex(1.050256f, 9.023541f);
	gi.Vertex(1.050256f, 9.334698f);
	gi.Vertex(0.196923f, 9.007165f);
    gi.End();

    gi.BeginTriangleStrip();
	gi.Vertex(2.363077f, 9.711361f);
	gi.Vertex(2.264615f, 9.023541f);
	gi.Vertex(3.282051f, 9.563972f);
	gi.Vertex(3.446154f, 9.023541f);
	gi.Vertex(4.069744f, 9.531218f);
	gi.Vertex(4.299487f, 9.236438f);
	gi.Vertex(4.644103f, 9.613101f);
	gi.Vertex(5.251282f, 9.875128f);
    gi.End();
}

void draw_letters ( GraphicInterface & gi )
{
    gi.DisableDepthTest();

    draw_i(gi);
    gi.Translate(3.0,  0.0,  0.0);

    draw_d(gi);
    gi.Translate(6.0,  0.0,  0.0);

    draw_e(gi);
    gi.Translate(5.0,  0.0,  0.0);

    draw_a(gi);
    gi.Translate(6.0,  0.0,  0.0);

    draw_s(gi);
    gi.Translate(10.0,  0.0,  0.0);

    draw_i(gi);
    gi.Translate(3.0,  0.0,  0.0);

    draw_n(gi);
    gi.Translate(-31.0,  -13.0,  0.0);

    draw_m(gi);
    gi.Translate(10.0,  0.0,  0.0);

    draw_o(gi);
    gi.Translate(5.0,  0.0,  0.0);

    draw_t(gi);
    gi.Translate(4.0,  0.0,  0.0);

    draw_i(gi);
    gi.Translate(3.5,  0.0,  0.0);

    draw_o(gi);
    gi.Translate(5.0,  0.0,  0.0);

    draw_n(gi);
}

void draw_under_table ( GraphicInterface & gi )
{
    gi.Color(0., 0., 0.);
	gi.BeginQuads();
    gi.Vertex( 3.f, 0.f, 3.f);
    gi.Vertex( 3.f, 0.f,-3.f);
    gi.Vertex(-3.f, 0.f,-3.f);
    gi.Vertex(-3.f, 0.f, 3.f);
	gi.End();
}