
#include <math.h>
#include "GraphicInterface.h"

#define DRAW_LOGO 		 1
#define DRAW_LAMP        2
#define DRAW_LETTERS	 3
#define DRAW_3D_LOGO 	 4
#define DRAW_UNDER_TABLE 5
#define DRAW_SHADOW1     6
#define DRAW_SHADOW2     7
#define DRAW_TABLE       8
#define LOGO_ROTATE      9

#define M_PI 3.14159265358979323846

void draw_lamp ( GraphicInterface & gi );
void draw_logo ( GraphicInterface & gi );
void draw_letters ( GraphicInterface & gi );
void draw_under_table ( GraphicInterface & gi );
void logo_dlist ( GraphicInterface & gi );

typedef float vector[3];
typedef float vector4[4];
typedef vector parameter[4];

#define TABLERES 12

enum intIndex
{
    ii_i, ii_j, ii_k, ii_s, ii_start
};

enum floatIndex
{
    fi_x, fi_y, fi_z,
    fi_lv_x, fi_lv_y, fi_lv_z,
    fi_ov_x, fi_ov_y, fi_ov_z,
    fi_c, fi_1_c,
    fi_perspective,
    fi_viewport = fi_perspective + 4,
    fi_cur_time = fi_viewport + 4,
    fi_view_from,
    fi_view_to = fi_view_from + 3,
    fi_view_up_x = fi_view_to + 3, fi_view_up_y, fi_view_up_z,
    fi_lamp_rot_y,
    fi_lamp_rot_z = fi_lamp_rot_y + 4,
    fi_logo_rot_x = fi_lamp_rot_z + 4,
    fi_logo_rot_y = fi_logo_rot_x + 4,
    fi_logo_rot_z = fi_logo_rot_y + 4,
    fi_logo_rot = fi_logo_rot_z + 4,
    fi_logo_pos_x = fi_logo_rot + 3, fi_logo_pos_y, fi_logo_pos_z,
    fi_light_pos_x, fi_light_pos_y, fi_light_pos_z, fi_light_pos_w,
    fi_shadow_r, fi_shadow_g, fi_shadow_b,
    fi_blank_r, fi_blank_g, fi_blank_b,
    fi_tv00, fi_tv01, fi_tv02, fi_tv03,
    fi_tv10, fi_tv11, fi_tv12, fi_tv13,
    fi_tv20, fi_tv21, fi_tv22, fi_tv23,
    fi_tv30, fi_tv31, fi_tv32, fi_tv33,
    fi_view_to_spline,
    fi_view_from_spline = fi_view_to_spline + 144,
    fi_light_pos_spline = fi_view_from_spline + 144,
    fi_logo_pos_spline = fi_light_pos_spline + 144,
    fi_logo_rot_spline = fi_logo_pos_spline + 144,
    fi_table_points = fi_logo_rot_spline + 144,
    fi_table_colors = fi_table_points + 3*(TABLERES+1)*(TABLERES+1),
};

vector light_pos_ctl[] = {

    {0.0, 1.8f, 0.0},
    {0.0, 1.8f, 0.0},
    {0.0, 1.6f, 0.0},

    {0.0, 1.6f, 0.0},
    {0.0, 1.6f, 0.0},
    {0.0, 1.6f, 0.0},
    {0.0, 1.4f, 0.0},

    {0.0, 1.3f, 0.0},
    {-0.2f, 1.5f, 2.0},
    {0.8f, 1.5f, -0.4f},
    {-0.8f, 1.5f, -0.4f},

    {0.8f, 2.0, 1.0},
    {1.8f, 5.0, -1.8f},
    {8.0, 10.0, -4.0},
    {8.0, 10.0, -4.0},
    {8.0, 10.0, -4.0},
};

vector logo_pos_ctl[] = {

    {0.0, -0.5f, 0.0},

    {0.0, -0.5f, 0.0},
    {0.0, -0.5f, 0.0},

    {0.0, -0.5f, 0.0},
    {0.0, -0.5f, 0.0},
    {0.0, -0.5f, 0.0},
    {0.0, 0.0, 0.0},

    {0.0, 0.6f, 0.0},
    {0.0, 0.75f, 0.0},
    {0.0, 0.8f, 0.0},
    {0.0, 0.8f, 0.0},

    {0.0, 0.5f, 0.0},
    {0.0, 0.5f, 0.0},
    {0.0, 0.5f, 0.0},
    {0.0, 0.5f, 0.0},
    {0.0, 0.5f, 0.0},
};


vector logo_rot_ctl[] = {

    {0.0, 0.0, -18.4f},

    {0.0, 0.0, -18.4f},
    {0.0, 0.0, -18.4f},

    {0.0, 0.0, -18.4f},
    {0.0, 0.0, -18.4f},
    {0.0, 0.0, -18.4f},
    {0.0, 0.0, -18.4f},
    {0.0, 0.0, -18.4f},

    {240.0, 360.0, 180.0},
    {90.0, 180.0, 90.0},

    {11.9f, 0.0, -18.4f},
    {11.9f, 0.0, -18.4f},
    {11.9f, 0.0, -18.4f},
    {11.9f, 0.0, -18.4f},
    {11.9f, 0.0, -18.4f},
};


vector view_from_ctl[] = {

    {-1.0, 1.0, -4.0},

    {-1.0, -3.0, -4.0},	/* 0 */
    {-3.0, 1.0, -3.0},	/* 1 */

    {-1.8f, 2.0, 5.4f},	/* 2 */
    {-0.4f, 2.0, 1.2f},	/* 3 */
    {-0.2f, 1.5f, 0.6f},	/* 4 */
    {-0.2f, 1.2f, 0.6f},	/* 5 */

    {-0.8f, 1.0, 2.4f},	/* 6 */
    {-1.0, 2.0, 3.0},	/* 7 */
    {0.0, 4.0, 3.6f},	/* 8 */
    {-0.8f, 4.0, 1.2f},	/* 9 */

    {-0.2f, 3.0, 0.6f},	/* 10 */
    {-0.1f, 2.0, 0.3f},	/* 11 */
    {-0.1f, 2.0, 0.3f},	/* 12 */
    {-0.1f, 2.0, 0.3f},	/* 13 */
    {-0.1f, 2.0, 0.3f},	/* 13 */


};

vector view_to_ctl[] = {

    {-1.0, 1.0, 0.0},

    {-1.0, -3.0, 0.0},
    {-1.0, 1.0, 0.0},

    {0.1f, 0.0, -0.3f},
    {0.1f, 0.0, -0.3f},
    {0.1f, 0.0, -0.3f},
    {0.0, 0.2f, 0.0},

    {0.0, 0.6f, 0.0},
    {0.0, 0.8f, 0.0},
    {0.0, 0.8f, 0.0},
    {0.0, 0.8f, 0.0},

    {0.0, 0.8f, 0.0},
    {0.0, 0.8f, 0.0},
    {0.0, 0.8f, 0.0},
    {0.0, 0.8f, 0.0},
    {0.0, 0.8f, 0.0},

};

void draw_table ( GraphicInterface & gi )
{
    gi.FloatAstDD ( fi_ov_x, fi_light_pos_x );
    gi.FloatAstDD ( fi_ov_y, fi_light_pos_y );
    gi.FloatAstDD ( fi_ov_z, fi_light_pos_z );
    gi.FloatSubDD ( fi_ov_x, fi_logo_pos_x );
    gi.FloatSubDD ( fi_ov_y, fi_logo_pos_y );
    gi.FloatSubDD ( fi_ov_z, fi_logo_pos_z );
// normalize ov
    gi.FloatAstDD ( fi_x, fi_ov_x );
    gi.FloatAstDD ( fi_y, fi_ov_y );
    gi.FloatAstDD ( fi_z, fi_ov_z );
    gi.FloatMulDD ( fi_x, fi_x );
    gi.FloatMulDD ( fi_y, fi_y );
    gi.FloatMulDD ( fi_z, fi_z );
    gi.FloatAddDD ( fi_x, fi_y );
    gi.FloatAddDD ( fi_x, fi_z );
    gi.FloatSqrt ( fi_x );
    gi.FloatDivDD ( fi_ov_x, fi_x );
    gi.FloatDivDD ( fi_ov_y, fi_x );
    gi.FloatDivDD ( fi_ov_z, fi_x );

    gi.IntAstDC ( ii_j, 0 );
    gi.Do();

        gi.IntAstDC ( ii_i, 0 );
        gi.Do();

            gi.IntAstDC ( ii_s, 13 );
            gi.IntMulDD ( ii_s, ii_j );
            gi.IntAddDD ( ii_s, ii_i );
            gi.IntMulDC ( ii_s, 3 );
            gi.IntAstDC ( ii_k, fi_table_points );
            gi.IntAddDD ( ii_k, ii_s );
            gi.FloatAstDD ( fi_lv_x, fi_light_pos_x );
            gi.FloatAstDD ( fi_lv_y, fi_light_pos_y );
            gi.FloatAstDD ( fi_lv_z, fi_light_pos_z );
            gi.FloatAstDI ( fi_c, ii_k );
            gi.FloatSubDD ( fi_lv_x, fi_c );
            gi.IntAddDC ( ii_k, 1 );
            gi.FloatAstDI ( fi_c, ii_k );
            gi.FloatSubDD ( fi_lv_y, fi_c );
            gi.IntAddDC ( ii_k, 1 );
            gi.FloatAstDI ( fi_c, ii_k );
            gi.FloatSubDD ( fi_lv_z, fi_c );
// normalize lv
            gi.FloatAstDD ( fi_x, fi_lv_x );
            gi.FloatAstDD ( fi_y, fi_lv_y );
            gi.FloatAstDD ( fi_z, fi_lv_z );
            gi.FloatMulDD ( fi_x, fi_x );
            gi.FloatMulDD ( fi_y, fi_y );
            gi.FloatMulDD ( fi_z, fi_z );
            gi.FloatAddDD ( fi_x, fi_y );
            gi.FloatAddDD ( fi_x, fi_z );
            gi.FloatSqrt ( fi_x );
            gi.FloatDivDD ( fi_lv_x, fi_x );
            gi.FloatDivDD ( fi_lv_y, fi_x );
            gi.FloatDivDD ( fi_lv_z, fi_x );

            gi.FloatAstDD ( fi_x, fi_lv_x );
            gi.FloatAstDD ( fi_y, fi_lv_y );
            gi.FloatAstDD ( fi_z, fi_lv_z );
            gi.FloatMulDD ( fi_x, fi_ov_x );
            gi.FloatMulDD ( fi_y, fi_ov_y );
            gi.FloatMulDD ( fi_z, fi_ov_z );
            gi.FloatAddDD ( fi_x, fi_y );
            gi.FloatAddDD ( fi_x, fi_z );

            gi.IfFloatDC ( fi_x, LE, 0 );
            gi.FloatAstDC ( fi_x, 0 );
            gi.Else();
            gi.FloatMulDD ( fi_x, fi_x );
            gi.FloatMulDD ( fi_x, fi_lv_y );
            gi.EndIf();

            gi.IfFloatDC ( fi_cur_time, GT, 10 );
            gi.FloatAstDC ( fi_y, 12.0f );
            gi.FloatSubDD ( fi_y, fi_cur_time );
            gi.FloatMulDC ( fi_y, 0.5f );
            gi.FloatMulDD ( fi_x, fi_y );
            gi.EndIf();

            gi.IntAstDC ( ii_k, fi_table_colors );
            gi.IntAddDD ( ii_k, ii_s );
            gi.FloatAstID ( ii_k, fi_x );
            gi.IntAddDC ( ii_k, 1 );
            gi.FloatAstID ( ii_k, fi_x );
            gi.IntAddDC ( ii_k, 1 );
            gi.FloatAstID ( ii_k, fi_x );

            gi.IntAddDC ( ii_i, 1 );

        gi.WhileIntDC ( ii_i, LE, 12 );

        gi.IntAddDC ( ii_j, 1 );

    gi.WhileIntDC ( ii_j, LE, 12 );

    gi.DisableDepthTest();
    gi.DisableLighting();

    gi.IntAstDC ( ii_j, 0 );
    gi.Do();

        gi.BeginTriangleStrip();
        gi.IntAstDC ( ii_i, 0 );
        gi.Do();

            gi.IntAstDC ( ii_s, 13 );
            gi.IntMulDD ( ii_s, ii_j );
            gi.IntAddDD ( ii_s, ii_i );
            gi.IntMulDC ( ii_s, 3 );

            gi.IntAstDC ( ii_k, fi_table_colors );
            gi.IntAddDD ( ii_k, ii_s );
            gi.FloatAstDI ( fi_x, ii_k );
            gi.IntAddDC ( ii_k, 1 );
            gi.FloatAstDI ( fi_y, ii_k );
            gi.IntAddDC ( ii_k, 1 );
            gi.FloatAstDI ( fi_z, ii_k );
            gi.Color3v ( fi_x );
            gi.IntAstDC ( ii_k, fi_table_points );
            gi.IntAddDD ( ii_k, ii_s );
            gi.FloatAstDI ( fi_x, ii_k );
            gi.IntAddDC ( ii_k, 1 );
            gi.FloatAstDI ( fi_y, ii_k );
            gi.IntAddDC ( ii_k, 1 );
            gi.FloatAstDI ( fi_z, ii_k );
            gi.Vertex3v ( fi_x );
            
            gi.IntAddDC ( ii_s, 39 );
            gi.IntAstDC ( ii_k, fi_table_colors );
            gi.IntAddDD ( ii_k, ii_s );
            gi.FloatAstDI ( fi_x, ii_k );
            gi.IntAddDC ( ii_k, 1 );
            gi.FloatAstDI ( fi_y, ii_k );
            gi.IntAddDC ( ii_k, 1 );
            gi.FloatAstDI ( fi_z, ii_k );
            gi.Color3v ( fi_x );
            gi.IntAstDC ( ii_k, fi_table_points );
            gi.IntAddDD ( ii_k, ii_s );
            gi.FloatAstDI ( fi_x, ii_k );
            gi.IntAddDC ( ii_k, 1 );
            gi.FloatAstDI ( fi_y, ii_k );
            gi.IntAddDC ( ii_k, 1 );
            gi.FloatAstDI ( fi_z, ii_k );
            gi.Vertex3v ( fi_x );

            gi.IntAddDC ( ii_i, 1 );

        gi.WhileIntDC ( ii_i, LE, 12 );
	    gi.End();

        gi.IntAddDC ( ii_j, 1 );

    gi.WhileIntDC ( ii_j, LT, 12 );

    gi.EnableDepthTest();

    vector paper_points[4] = {
                                {-0.8f, 0.0f, 0.4f},
                                {-0.2f, 0.0f, -1.4f},
                                {1.0f, 0.0f, -1.0f},
                                {0.4f, 0.0f, 0.8f},
                             };

    gi.BeginPolygon();
    for ( int i = 0; i < 4; i++ )
    {
        gi.FloatAstDD ( fi_lv_x, fi_light_pos_x );
        gi.FloatAstDD ( fi_lv_y, fi_light_pos_y );
        gi.FloatAstDD ( fi_lv_z, fi_light_pos_z );
        gi.FloatAstDC ( fi_x, paper_points[i][0] );
        gi.FloatAstDC ( fi_y, paper_points[i][1] );
        gi.FloatAstDC ( fi_z, paper_points[i][2] );
        gi.FloatSubDD ( fi_lv_x, fi_x );
        gi.FloatSubDD ( fi_lv_y, fi_y );
        gi.FloatSubDD ( fi_lv_z, fi_z );
// normalize lv
        gi.FloatAstDD ( fi_x, fi_lv_x );
        gi.FloatAstDD ( fi_y, fi_lv_y );
        gi.FloatAstDD ( fi_z, fi_lv_z );
        gi.FloatMulDD ( fi_x, fi_x );
        gi.FloatMulDD ( fi_y, fi_y );
        gi.FloatMulDD ( fi_z, fi_z );
        gi.FloatAddDD ( fi_x, fi_y );
        gi.FloatAddDD ( fi_x, fi_z );
        gi.FloatSqrt ( fi_x );
        gi.FloatDivDD ( fi_lv_x, fi_x );
        gi.FloatDivDD ( fi_lv_y, fi_x );
        gi.FloatDivDD ( fi_lv_z, fi_x );

        gi.FloatAstDD ( fi_x, fi_lv_x );
        gi.FloatAstDD ( fi_y, fi_lv_y );
        gi.FloatAstDD ( fi_z, fi_lv_z );
        gi.FloatMulDD ( fi_x, fi_ov_x );
        gi.FloatMulDD ( fi_y, fi_ov_y );
        gi.FloatMulDD ( fi_z, fi_ov_z );
        gi.FloatAddDD ( fi_x, fi_y );
        gi.FloatAddDD ( fi_x, fi_z );

        gi.IfFloatDC ( fi_x, LE, 0 );
        gi.FloatAstDC ( fi_x, 0 );
        gi.Else();
        gi.FloatMulDD ( fi_x, fi_x );
        gi.FloatMulDD ( fi_x, fi_lv_y );
        gi.EndIf();

        gi.IfFloatDC ( fi_cur_time, GT, 10 );
        gi.FloatAstDC ( fi_y, 12.0f );
        gi.FloatSubDD ( fi_y, fi_cur_time );
        gi.FloatMulDC ( fi_y, 0.5 );
        gi.FloatMulDD ( fi_x, fi_y );
        gi.EndIf();

        gi.FloatAstDD ( fi_y, fi_x );
        gi.FloatAstDD ( fi_z, fi_x );
        gi.FloatMulDC ( fi_z, 0.8f );
	    gi.Color3v ( fi_x );
        gi.Vertex ( paper_points[i][0], paper_points[i][1], paper_points[i][2] );
    }
    gi.End();

    gi.PushMatrix();
    gi.Rotate (-18.4f, 0.0f, 1.0f, 0.0f);
    gi.Translate (-0.3f, 0.0f, -0.8f);
    gi.Rotate (-90.f, 1.0f, 0.0f, 0.0f);
    gi.Scale (0.015f, 0.015f, 0.015f);

    gi.FloatAstDD ( fi_x, fi_cur_time );
    gi.FloatMulDC ( fi_x, 0.5f );
    gi.FloatSubDC ( fi_x, 5.0f );
    gi.IfFloatDC ( fi_x, LT, 0 );
    gi.FloatAstDC ( fi_x, 0 );
    gi.EndIf();
    gi.FloatAstDD ( fi_y, fi_x );
    gi.FloatAstDD ( fi_z, fi_x );
	gi.Color3v ( fi_x );
    gi.CallList(DRAW_LETTERS);

    gi.PopMatrix();
}

parameter view_from_spline[12], view_to_spline[12],
	     light_pos_spline[12], logo_pos_spline[12], logo_rot_spline[12];

static void calc_spline ( GraphicInterface & gi, int v, int par )
{
    gi.IntAstFromFloat ( ii_i, fi_cur_time );
    gi.FloatAstDD ( fi_c, fi_cur_time );
    gi.FloatAstFromInt ( fi_x, ii_i );
    gi.FloatSubDD ( fi_c, fi_x );
    gi.IntAstDC ( ii_s, par );
    gi.IntMulDC ( ii_i, 12 );
    gi.IntAddDD ( ii_s, ii_i );
    for (int i=0; i<3; i++)
    {
        int k = v + i;
        gi.IntAstDC ( ii_j, k );
        gi.FloatAstII ( ii_j, ii_s );
        gi.IntAddDC ( ii_s, 1 );
        gi.FloatMulID ( ii_j, fi_c );
        gi.FloatAddII ( ii_j, ii_s );
        gi.IntAddDC ( ii_s, 1 );
        gi.FloatMulID ( ii_j, fi_c );
        gi.FloatAddII ( ii_j, ii_s );
        gi.IntAddDC ( ii_s, 1 );
        gi.FloatMulID ( ii_j, fi_c );
        gi.FloatAddII ( ii_j, ii_s );
        gi.IntAddDC ( ii_s, 1 );
    }
}

static void calc_spline_params ( vector *ctl_pts, int n, parameter *params )
{
    for ( int i=0; i<n-3; i++)
    {
	    for ( int j=0; j<3; j++)
        {
	        params[i][3][j] = ctl_pts[i+1][j];
	        params[i][2][j] = ctl_pts[i+2][j] - ctl_pts[i][j];
	        params[i][1][j] =  2.0f * ctl_pts[i][j] +
			          -2.0f * ctl_pts[i+1][j] +
			           1.0f * ctl_pts[i+2][j] +
			          -1.0f * ctl_pts[i+3][j];
	        params[i][0][j] = -1.0f * ctl_pts[i][j] +
			           1.0f * ctl_pts[i+1][j] +
			          -1.0f * ctl_pts[i+2][j] +
			           1.0f * ctl_pts[i+3][j];
	    }
    }
}

void idea ( GraphicInterface & gi )
{
    static bool ok = true;
    if(ok)
    {
        /* Stipple pattern */
        unsigned char stipple[128];
        for (int y = 0; y < 32; y++)
        for (int x = 0; x < 4; x++) 
          stipple[y * 4 + x] = (y % 2) ? 0xaa : 0x55;
        gi.PolygonStipple(stipple);

        gi.EnableLight(LIGHT_1);

        gi.LightAmbient ( LIGHT_1, 0.0, 0.0, 0.0, 1.0 );
        gi.LightDiffuse ( LIGHT_1, 1.0, 1.0, 1.0, 1.0 );
        gi.LightSpecular( LIGHT_1, 1.0, 1.0, 1.0, 1.0 );
        gi.LightPosition( LIGHT_1, 0.0, 1.0, 0.0, 0.0 );
    
        gi.LightAmbient ( LIGHT_2, 0.0, 0.0, 0.0, 1.0 );
        gi.LightDiffuse ( LIGHT_2, 0.3f,0.3f,0.5f,1.0 );
        gi.LightSpecular( LIGHT_2, 0.3f,0.3f,0.5f,1.0 );
        gi.LightPosition( LIGHT_2,-1.0, 0.0, 0.0, 0.0 );

        gi.LightAmbient ( LIGHT_3, 0.2f,0.2f,0.2f,1.0 );
        gi.LightDiffuse ( LIGHT_3, 0.2f,0.2f,0.2f,1.0 );
        gi.LightSpecular( LIGHT_3, 0.2f,0.2f,0.2f,1.0 );
        gi.LightPosition( LIGHT_3, 0.0,-1.0, 0.0, 0.0 );

        logo_dlist ( gi );
        gi.NewListCompile(DRAW_LOGO);
        draw_logo(gi);
        gi.EndList();

        gi.NewListCompile(DRAW_3D_LOGO);
        gi.EnableLighting();
        gi.EnableNormalize();
        gi.MaterialFrontAmbient(0.1f, 0.1f, 0.1f, 1.0); 
        gi.MaterialFrontDiffuse(0.5f, 0.4f, 0.7f, 1.0);
        gi.MaterialFrontSpecular(1.0, 1.0, 1.0, 1.0);
        gi.MaterialFrontShininess(30.);
        gi.CallList(DRAW_LOGO);
        gi.DisableNormalize();
        gi.EndList();

        gi.NewListCompile(DRAW_LAMP);
        draw_lamp(gi);
        gi.EndList();

        gi.NewListCompile(DRAW_LETTERS);
        draw_letters(gi);
        gi.EndList();

        gi.NewListCompile(DRAW_UNDER_TABLE);
        draw_under_table(gi);
        gi.EndList();

        calc_spline_params(view_from_ctl, 15, view_from_spline);
        calc_spline_params(view_to_ctl, 15, view_to_spline);
        calc_spline_params(light_pos_ctl, 15, light_pos_spline);
        calc_spline_params(logo_pos_ctl, 15, logo_pos_spline);
        calc_spline_params(logo_rot_ctl, 15, logo_rot_spline);

    gi.FloatAstDC ( fi_view_up_x, 0 );
    gi.FloatAstDC ( fi_view_up_y, 1 );
    gi.FloatAstDC ( fi_view_up_z, 0 );
    gi.FloatAstDC ( fi_lamp_rot_y+1, 0 );
    gi.FloatAstDC ( fi_lamp_rot_y+2, 1 );
    gi.FloatAstDC ( fi_lamp_rot_y+3, 0 );
    gi.FloatAstDC ( fi_lamp_rot_z+1, 0 );
    gi.FloatAstDC ( fi_lamp_rot_z+2, 0 );
    gi.FloatAstDC ( fi_lamp_rot_z+3, 1 );
    gi.FloatAstDC ( fi_logo_rot_x+1, 1 );
    gi.FloatAstDC ( fi_logo_rot_x+2, 0 );
    gi.FloatAstDC ( fi_logo_rot_x+3, 0 );
    gi.FloatAstDC ( fi_logo_rot_y+1, 0 );
    gi.FloatAstDC ( fi_logo_rot_y+2, 1 );
    gi.FloatAstDC ( fi_logo_rot_y+3, 0 );
    gi.FloatAstDC ( fi_logo_rot_z+1, 0 );
    gi.FloatAstDC ( fi_logo_rot_z+2, 0 );
    gi.FloatAstDC ( fi_logo_rot_z+3, 1 );
    gi.FloatAstDC ( fi_tv01, 0 );
    gi.FloatAstDC ( fi_tv02, 0 );
    gi.FloatAstDC ( fi_tv03, 0 );
    gi.FloatAstDC ( fi_tv10, 0 );
    gi.FloatAstDC ( fi_tv12, 0 );
    gi.FloatAstDC ( fi_tv13,-1 );
    gi.FloatAstDC ( fi_tv20, 0 );
    gi.FloatAstDC ( fi_tv21, 0 );
    gi.FloatAstDC ( fi_tv23, 0 );
    gi.FloatAstDC ( fi_tv30, 0 );
    gi.FloatAstDC ( fi_tv31, 0 );
    gi.FloatAstDC ( fi_tv32, 0 );
    gi.FloatAstDC ( fi_tv33, 0 );
    gi.FloatAstDC ( fi_perspective  , 45 );
    gi.FloatAstDC ( fi_perspective+2, 0.5 );
    gi.FloatAstDC ( fi_perspective+3, 20 );

    int par = fi_logo_rot_spline;
    for ( int j = 0; j < 12; j++ )
    for (int i=0; i<3; i++)
    {
        gi.FloatAstDC ( par++, logo_rot_spline[j][0][i] );
        gi.FloatAstDC ( par++, logo_rot_spline[j][1][i] );
        gi.FloatAstDC ( par++, logo_rot_spline[j][2][i] );
        gi.FloatAstDC ( par++, logo_rot_spline[j][3][i] );
    }
    par = fi_logo_pos_spline;
    for ( j = 0; j < 12; j++ )
    for (int i=0; i<3; i++)
    {
        gi.FloatAstDC ( par++, logo_pos_spline[j][0][i] );
        gi.FloatAstDC ( par++, logo_pos_spline[j][1][i] );
        gi.FloatAstDC ( par++, logo_pos_spline[j][2][i] );
        gi.FloatAstDC ( par++, logo_pos_spline[j][3][i] );
    }
    par = fi_light_pos_spline;
    for ( j = 0; j < 12; j++ )
    for (int i=0; i<3; i++)
    {
        gi.FloatAstDC ( par++, light_pos_spline[j][0][i] );
        gi.FloatAstDC ( par++, light_pos_spline[j][1][i] );
        gi.FloatAstDC ( par++, light_pos_spline[j][2][i] );
        gi.FloatAstDC ( par++, light_pos_spline[j][3][i] );
    }
    par = fi_view_to_spline;
    for ( j = 0; j < 12; j++ )
    for (int i=0; i<3; i++)
    {
        gi.FloatAstDC ( par++, view_to_spline[j][0][i] );
        gi.FloatAstDC ( par++, view_to_spline[j][1][i] );
        gi.FloatAstDC ( par++, view_to_spline[j][2][i] );
        gi.FloatAstDC ( par++, view_to_spline[j][3][i] );
    }
    par = fi_view_from_spline;
    for ( j = 0; j < 12; j++ )
    for (int i=0; i<3; i++)
    {
        gi.FloatAstDC ( par++, view_from_spline[j][0][i] );
        gi.FloatAstDC ( par++, view_from_spline[j][1][i] );
        gi.FloatAstDC ( par++, view_from_spline[j][2][i] );
        gi.FloatAstDC ( par++, view_from_spline[j][3][i] );
    }
        int s = 0;
        for ( j = 0; j <= TABLERES; j++ )
        {
	        for ( int i = 0; i <= TABLERES; i++ )
            {
                gi.FloatAstDC ( fi_table_points + s, (j-TABLERES/2.0f)/2.0f );
                ++s;
                gi.FloatAstDC ( fi_table_points + s, 0.0f );
                ++s;
                gi.FloatAstDC ( fi_table_points + s, (i-TABLERES/2.0f)/2.0f );
                ++s;
	        }
        }
        gi.Clock ( ii_start );
        ok = false;
    }
//////////////////////////////////////////////////
    gi.SetTimer(10);
    gi.NextStart();

    gi.Clock ( ii_s );
    gi.IntSubDD ( ii_s, ii_start );
    gi.FloatAstFromInt ( fi_cur_time, ii_s );
    gi.FloatMulDC ( fi_cur_time, 0.0005f );
    gi.FloatAddDC ( fi_cur_time, 0.5f );
    gi.IfFloatDC ( fi_cur_time, GT, 11.95f );
    gi.FloatAstDC ( fi_cur_time, 11.95f );
    gi.EndIf();

    calc_spline(gi, fi_logo_pos_x, fi_logo_pos_spline);
    calc_spline(gi, fi_logo_rot, fi_logo_rot_spline);
    calc_spline(gi, fi_light_pos_x, fi_light_pos_spline);
    calc_spline(gi, fi_view_to, fi_view_to_spline);
    calc_spline(gi, fi_view_from, fi_view_from_spline);

    gi.FloatAstDD ( fi_logo_rot_x, fi_logo_rot );
    gi.FloatAstDD ( fi_logo_rot_y, fi_logo_rot+1 );
    gi.FloatAstDD ( fi_logo_rot_z, fi_logo_rot+2 );
    gi.FloatAstDC ( fi_light_pos_w, 0. );
    gi.FloatAstDD ( fi_tv00, fi_light_pos_y );
    gi.FloatAstDD ( fi_tv11, fi_light_pos_y );
    gi.FloatAstDD ( fi_tv22, fi_light_pos_y );

    
    gi.ClearColorBuffer();
    gi.ClearDepthBuffer(); 

    gi.MatrixModeProjection();
    gi.LoadIdentity();
    gi.GetFloatViewport(fi_viewport);
    gi.FloatDivDD(fi_viewport+2, fi_viewport+3);
    gi.FloatMulDC(fi_viewport+2, 0.9f);
    gi.FloatAstDD(fi_perspective+1, fi_viewport+2);
    gi.Perspective4v(fi_perspective);

    gi.MatrixModeModelView();
    gi.LoadIdentity();
    gi.LookAt ( fi_view_from );

// Draw table

    gi.NewListCompile(DRAW_TABLE);
    draw_table(gi);
    gi.EndList();
    gi.IfFloatDC(fi_view_from+1, GT, 0 );
    gi.CallList(DRAW_TABLE);
    gi.EndIf();

// Draw shadow

    gi.NewListCompile(LOGO_ROTATE);
    gi.Rotate (-90.0, 1.0, 0.0, 0.0);
    gi.Rotate4v ( fi_logo_rot_z );
    gi.Rotate4v ( fi_logo_rot_y );
    gi.Rotate4v ( fi_logo_rot_x );
    gi.EndList();

    gi.NewListCompile(DRAW_SHADOW1);
    gi.Scale (0.04f,  0.0f,  0.04f);
    gi.CallList(LOGO_ROTATE);
    gi.CallList(DRAW_LOGO);
    gi.EndList();
    
    gi.NewListCompile ( DRAW_SHADOW2 );
    gi.Translate3v ( fi_light_pos_x );
    gi.MultMatrix ( fi_tv00 );

    gi.FloatAstDD ( fi_x, fi_logo_pos_x );
    gi.FloatAstDD ( fi_y, fi_logo_pos_y );
    gi.FloatAstDD ( fi_z, fi_logo_pos_z );
    
    gi.FloatSubDD ( fi_x, fi_light_pos_x );
    gi.FloatSubDD ( fi_y, fi_light_pos_y );
    gi.FloatSubDD ( fi_z, fi_light_pos_z );

    gi.Translate3v ( fi_x );
    gi.Scale (0.04f,  0.04f,  0.04f);
    gi.CallList(LOGO_ROTATE);
    gi.EnablePolygonStipple();
    gi.CallList(DRAW_LOGO);
    gi.DisablePolygonStipple();
    gi.EndList();

    gi.EnableCullFace(); 
    gi.DisableDepthTest(); 
    gi.PushMatrix();

    gi.FloatAstDD ( fi_c, fi_logo_pos_y );
    gi.FloatDivDC ( fi_c, 0.33f );
    gi.FloatAbs ( fi_c );
    gi.FloatAstDC ( fi_1_c, 1.f );
    gi.FloatSubDD ( fi_1_c, fi_c );

    gi.FloatAstDC ( fi_blank_r, 0.40f );
    gi.FloatAstDC ( fi_blank_g, 0.40f );
    gi.FloatAstDC ( fi_blank_b, 0.32f );
    gi.FloatMulDD ( fi_blank_r, fi_1_c );
    gi.FloatMulDD ( fi_blank_g, fi_1_c );
    gi.FloatMulDD ( fi_blank_b, fi_1_c );
// Still under table 
    gi.FloatAstDC ( fi_shadow_r, 0.25f );
    gi.FloatAstDC ( fi_shadow_g, 0.20f );
    gi.FloatAstDC ( fi_shadow_b, 0.35f );
// We're emerging from the table 
    gi.IfFloatDC ( fi_logo_pos_y, GT, -0.33f );
    gi.FloatMulDD ( fi_shadow_r, fi_c );
    gi.FloatMulDD ( fi_shadow_g, fi_c );
    gi.FloatMulDD ( fi_shadow_b, fi_c );
    gi.FloatAddDD ( fi_shadow_r, fi_blank_r );
    gi.FloatAddDD ( fi_shadow_g, fi_blank_g );
    gi.FloatAddDD ( fi_shadow_b, fi_blank_b );
    gi.EndIf();

    gi.IfFloatDC ( fi_logo_pos_y, GT, 0 );
    gi.FloatAstDD ( fi_shadow_r, fi_blank_r );
    gi.FloatAstDD ( fi_shadow_g, fi_blank_g );
    gi.FloatAstDD ( fi_shadow_b, fi_blank_b );
    gi.EndIf();

    gi.IfFloatDC ( fi_logo_pos_y, GT, 0.33f );
    gi.FloatAstDC ( fi_shadow_r, 0 );
    gi.FloatAstDC ( fi_shadow_g, 0 );
    gi.FloatAstDC ( fi_shadow_b, 0 );
    gi.EndIf();

	gi.Color3v(fi_shadow_r);
    gi.IfFloatDC(fi_logo_pos_y, LT, 0 );
    gi.CallList(DRAW_SHADOW1);
    gi.Else();
    gi.CallList(DRAW_SHADOW2);
    gi.EndIf();
    gi.PopMatrix();

// Draw lamp

    gi.EnableDepthTest();
    gi.DisableCullFace();

    gi.PushMatrix();
    gi.Translate3v(fi_light_pos_x);
    gi.Scale ( 0.1f,  0.1f,  0.1f );

    gi.FloatAstDD ( fi_x, fi_light_pos_x );
    gi.FloatAstDD ( fi_y, fi_light_pos_y );
    gi.FloatAstDD ( fi_z, fi_light_pos_z );

    gi.FloatSubDD ( fi_x, fi_logo_pos_x );
    gi.FloatSubDD ( fi_y, fi_logo_pos_y );
    gi.FloatSubDD ( fi_z, fi_logo_pos_z );
    
    gi.FloatAstDD ( fi_lamp_rot_y, fi_z );
    gi.FloatAtan2 ( fi_lamp_rot_y, fi_x );
    gi.FloatMulDC   ( fi_lamp_rot_y, float (-180.0/M_PI) );

    gi.FloatMulDD   ( fi_x, fi_x );
    gi.FloatMulDD   ( fi_z, fi_z );
    gi.FloatAddDD ( fi_x, fi_z );
    gi.FloatSqrt  ( fi_x );
    gi.FloatAstDD ( fi_lamp_rot_z, fi_x );
    gi.FloatAtan2 ( fi_lamp_rot_z, fi_y );
    gi.FloatMulDC   ( fi_lamp_rot_z, float (-180.0/M_PI) );
    
    gi.Rotate4v ( fi_lamp_rot_y );
    gi.Rotate4v ( fi_lamp_rot_z );
    gi.Rotate (-90.0, 1.0, 0.0, 0.0);

    gi.CallList(DRAW_LAMP);
    gi.PopMatrix();

// Draw logo 

    gi.LightPosition4v ( LIGHT_1, fi_light_pos_x );
    gi.PushMatrix();
    gi.Translate3v ( fi_logo_pos_x );
    gi.Scale (0.04f,  0.04f,  0.04f);
    gi.CallList(LOGO_ROTATE);
    gi.IfFloatDC ( fi_logo_pos_y, GT, -0.33f );
    gi.CallList ( DRAW_3D_LOGO );
    gi.EndIf();
    gi.PopMatrix();

// Draw under table

    gi.IfFloatDC ( fi_view_from+1, LT, 0 );
    gi.CallList ( DRAW_UNDER_TABLE );
    gi.EndIf();
}
