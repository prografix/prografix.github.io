
#include "GraphicInterface.h"

#define DRAW_ELBOW  21
#define DRAW_DOUBLE 22
#define DRAW_SINGLE 23

static void draw_single_cylinder ( GraphicInterface & gi )
{
    gi.BeginTriangleStrip();
    gi.Normal( 1.000000f, 0.000000f, 0.000000);  gi.Vertex( 1.000000f, 0.000000f, 0.000000);
    gi.Normal( 1.000000f, 0.000000f, 0.000000);  gi.Vertex( 1.000000f, 0.000000f, 5.000000);
    gi.Normal( 0.707107f, 0.707107f, 0.000000);  gi.Vertex( 0.707107f, 0.707107f, 0.000000);
    gi.Normal( 0.707107f, 0.707107f, 0.000000);  gi.Vertex( 0.707107f, 0.707107f, 5.000000);
    gi.Normal( 0.000000f, 1.000000f, 0.000000);  gi.Vertex( 0.000000f, 1.000000f, 0.000000);
    gi.Normal( 0.000000f, 1.000000f, 0.000000);  gi.Vertex( 0.000000f, 1.000000f, 5.000000);
    gi.Normal(-0.707107f, 0.707107f, 0.000000);  gi.Vertex(-0.707107f, 0.707107f, 0.000000);
    gi.Normal(-0.707107f, 0.707107f, 0.000000);  gi.Vertex(-0.707107f, 0.707107f, 5.000000);
    gi.Normal(-1.000000f, 0.000000f, 0.000000);  gi.Vertex(-1.000000f, 0.000000f, 0.000000);
    gi.Normal(-1.000000f, 0.000000f, 0.000000);  gi.Vertex(-1.000000f, 0.000000f, 5.000000);
    gi.Normal(-0.707107f,-0.707107f, 0.000000);  gi.Vertex(-0.707107f,-0.707107f, 0.000000);
    gi.Normal(-0.707107f,-0.707107f, 0.000000);  gi.Vertex(-0.707107f,-0.707107f, 5.000000);
    gi.Normal( 0.000000f,-1.000000f, 0.000000);  gi.Vertex( 0.000000f,-1.000000f, 0.000000);
    gi.Normal( 0.000000f,-1.000000f, 0.000000);  gi.Vertex( 0.000000f,-1.000000f, 5.000000);
    gi.Normal( 0.707107f,-0.707107f, 0.000000);  gi.Vertex( 0.707107f,-0.707107f, 0.000000);
    gi.Normal( 0.707107f,-0.707107f, 0.000000);  gi.Vertex( 0.707107f,-0.707107f, 5.000000);
    gi.Normal( 1.000000f, 0.000000f, 0.000000);  gi.Vertex( 1.000000f, 0.000000f, 0.000000);
    gi.Normal( 1.000000f, 0.000000f, 0.000000);  gi.Vertex( 1.000000f, 0.000000f, 5.000000);
    gi.End();
}

static void draw_double_cylinder ( GraphicInterface & gi )
{
    gi.BeginTriangleStrip();
    gi.Normal( 1.000000f, 0.000000f, 0.000000);  gi.Vertex( 1.000000f, 0.000000f, 0.000000);
    gi.Normal( 1.000000f, 0.000000f, 0.000000);  gi.Vertex( 1.000000f, 0.000000f, 7.000000);
    gi.Normal( 0.707107f, 0.707107f, 0.000000);  gi.Vertex( 0.707107f, 0.707107f, 0.000000);
    gi.Normal( 0.707107f, 0.707107f, 0.000000);  gi.Vertex( 0.707107f, 0.707107f, 7.000000);
    gi.Normal( 0.000000f, 1.000000f, 0.000000);  gi.Vertex( 0.000000f, 1.000000f, 0.000000);
    gi.Normal( 0.000000f, 1.000000f, 0.000000);  gi.Vertex( 0.000000f, 1.000000f, 7.000000);
    gi.Normal(-0.707107f, 0.707107f, 0.000000);  gi.Vertex(-0.707107f, 0.707107f, 0.000000);
    gi.Normal(-0.707107f, 0.707107f, 0.000000);  gi.Vertex(-0.707107f, 0.707107f, 7.000000);
    gi.Normal(-1.000000f, 0.000000f, 0.000000);  gi.Vertex(-1.000000f, 0.000000f, 0.000000);
    gi.Normal(-1.000000f, 0.000000f, 0.000000);  gi.Vertex(-1.000000f, 0.000000f, 7.000000);
    gi.Normal(-0.707107f,-0.707107f, 0.000000);  gi.Vertex(-0.707107f,-0.707107f, 0.000000);
    gi.Normal(-0.707107f,-0.707107f, 0.000000);  gi.Vertex(-0.707107f,-0.707107f, 7.000000);
    gi.Normal( 0.000000f,-1.000000f, 0.000000);  gi.Vertex( 0.000000f,-1.000000f, 0.000000);
    gi.Normal( 0.000000f,-1.000000f, 0.000000);  gi.Vertex( 0.000000f,-1.000000f, 7.000000);
    gi.Normal( 0.707107f,-0.707107f, 0.000000);  gi.Vertex( 0.707107f,-0.707107f, 0.000000);
    gi.Normal( 0.707107f,-0.707107f, 0.000000);  gi.Vertex( 0.707107f,-0.707107f, 7.000000);
    gi.Normal( 1.000000f, 0.000000f, 0.000000);  gi.Vertex( 1.000000f, 0.000000f, 0.000000);
    gi.Normal( 1.000000f, 0.000000f, 0.000000);  gi.Vertex( 1.000000f, 0.000000f, 7.000000);
    gi.End();
}

static void draw_elbow ( GraphicInterface & gi )
{
    gi.BeginTriangleStrip();
    gi.Normal( 1.000000f, 0.000000f, 0.000000f); gi.Vertex( 1.000000f, 0.000000f, 0.000000f);
    gi.Normal( 1.000000f, 0.000000f, 0.000000f); gi.Vertex( 1.000000f, 0.034074f, 0.258819f);
    gi.Normal( 0.707107f, 0.707107f, 0.000000f); gi.Vertex( 0.707107f, 0.707107f, 0.000000f);
    gi.Normal( 0.707107f, 0.683013f,-0.183013f); gi.Vertex( 0.707107f, 0.717087f, 0.075806f);
    gi.Normal( 0.000000f, 1.000000f, 0.000000f); gi.Vertex( 0.000000f, 1.000000f, 0.000000f);
    gi.Normal( 0.000000f, 0.965926f,-0.258819f); gi.Vertex( 0.000000f, 1.000000f, 0.000000f);
    gi.Normal(-0.707107f, 0.707107f, 0.000000f); gi.Vertex(-0.707107f, 0.707107f, 0.000000f);
    gi.Normal(-0.707107f, 0.683013f,-0.183013f); gi.Vertex(-0.707107f, 0.717087f, 0.075806f);
    gi.Normal(-1.000000f, 0.000000f, 0.000000f); gi.Vertex(-1.000000f, 0.000000f, 0.000000f);
    gi.Normal(-1.000000f, 0.000000f, 0.000000f); gi.Vertex(-1.000000f, 0.034074f, 0.258819f);
    gi.Normal(-0.707107f,-0.707107f, 0.000000f); gi.Vertex(-0.707107f,-0.707107f, 0.000000f);
    gi.Normal(-0.707107f,-0.683013f, 0.183013f); gi.Vertex(-0.707107f,-0.648939f, 0.441832f);
    gi.Normal( 0.000000f,-1.000000f, 0.000000f); gi.Vertex( 0.000000f,-1.000000f, 0.000000f);
    gi.Normal( 0.000000f,-0.965926f, 0.258819f); gi.Vertex( 0.000000f,-0.931852f, 0.517638f);
    gi.Normal( 0.707107f,-0.707107f, 0.000000f); gi.Vertex( 0.707107f,-0.707107f, 0.000000f);
    gi.Normal( 0.707107f,-0.683013f, 0.183013f); gi.Vertex( 0.707107f,-0.648939f, 0.441832f);
    gi.Normal( 1.000000f, 0.000000f, 0.000000f); gi.Vertex( 1.000000f, 0.000000f, 0.000000f);
    gi.Normal( 1.000000f, 0.000000f, 0.000000f); gi.Vertex( 1.000000f, 0.034074f, 0.258819f);
    gi.End();
    gi.BeginTriangleStrip();
    gi.Normal( 1.000000f, 0.000000f, 0.000000f); gi.Vertex( 1.000000f, 0.034074f, 0.258819f);
    gi.Normal( 1.000000f, 0.000000f, 0.000000f); gi.Vertex( 1.000000f, 0.133975f, 0.500000f);
    gi.Normal( 0.707107f, 0.683013f,-0.183013f); gi.Vertex( 0.707107f, 0.717087f, 0.075806f);
    gi.Normal( 0.707107f, 0.612372f,-0.353553f); gi.Vertex( 0.707107f, 0.746347f, 0.146447f);
    gi.Normal( 0.000000f, 0.965926f,-0.258819f); gi.Vertex( 0.000000f, 1.000000f, 0.000000f);
    gi.Normal( 0.000000f, 0.866025f,-0.500000f); gi.Vertex( 0.000000f, 1.000000f, 0.000000f);
    gi.Normal(-0.707107f, 0.683013f,-0.183013f); gi.Vertex(-0.707107f, 0.717087f, 0.075806f);
    gi.Normal(-0.707107f, 0.612372f,-0.353553f); gi.Vertex(-0.707107f, 0.746347f, 0.146447f);
    gi.Normal(-1.000000f, 0.000000f, 0.000000f); gi.Vertex(-1.000000f, 0.034074f, 0.258819f);
    gi.Normal(-1.000000f, 0.000000f, 0.000000f); gi.Vertex(-1.000000f, 0.133975f, 0.500000f);
    gi.Normal(-0.707107f,-0.683013f, 0.183013f); gi.Vertex(-0.707107f,-0.648939f, 0.441832f);
    gi.Normal(-0.707107f,-0.612372f, 0.353553f); gi.Vertex(-0.707107f,-0.478398f, 0.853553f);
    gi.Normal( 0.000000f,-0.965926f, 0.258819f); gi.Vertex( 0.000000f,-0.931852f, 0.517638f);
    gi.Normal( 0.000000f,-0.866025f, 0.500000f); gi.Vertex( 0.000000f,-0.732051f, 1.000000f);
    gi.Normal( 0.707107f,-0.683013f, 0.183013f); gi.Vertex( 0.707107f,-0.648939f, 0.441832f);
    gi.Normal( 0.707107f,-0.612372f, 0.353553f); gi.Vertex( 0.707107f,-0.478398f, 0.853553f);
    gi.Normal( 1.000000f, 0.000000f, 0.000000f); gi.Vertex( 1.000000f, 0.034074f, 0.258819f);
    gi.Normal( 1.000000f, 0.000000f, 0.000000f); gi.Vertex( 1.000000f, 0.133975f, 0.500000f);
    gi.End();
    gi.BeginTriangleStrip();
    gi.Normal( 1.000000f, 0.000000f, 0.000000f); gi.Vertex( 1.000000f, 0.133975f, 0.500000f);
    gi.Normal( 1.000000f, 0.000000f, 0.000000f); gi.Vertex( 1.000000f, 0.292893f, 0.707107f);
    gi.Normal( 0.707107f, 0.612372f,-0.353553f); gi.Vertex( 0.707107f, 0.746347f, 0.146447f);
    gi.Normal( 0.707107f, 0.500000f,-0.500000f); gi.Vertex( 0.707107f, 0.792893f, 0.207107f);
    gi.Normal( 0.000000f, 0.866025f,-0.500000f); gi.Vertex( 0.000000f, 1.000000f, 0.000000f);
    gi.Normal( 0.000000f, 0.707107f,-0.707107f); gi.Vertex( 0.000000f, 1.000000f, 0.000000f);
    gi.Normal(-0.707107f, 0.612372f,-0.353553f); gi.Vertex(-0.707107f, 0.746347f, 0.146447f);
    gi.Normal(-0.707107f, 0.500000f,-0.500000f); gi.Vertex(-0.707107f, 0.792893f, 0.207107f);
    gi.Normal(-1.000000f, 0.000000f, 0.000000f); gi.Vertex(-1.000000f, 0.133975f, 0.500000f);
    gi.Normal(-1.000000f, 0.000000f, 0.000000f); gi.Vertex(-1.000000f, 0.292893f, 0.707107f);
    gi.Normal(-0.707107f,-0.612372f, 0.353553f); gi.Vertex(-0.707107f,-0.478398f, 0.853553f);
    gi.Normal(-0.707107f,-0.500000f, 0.500000f); gi.Vertex(-0.707107f,-0.207107f, 1.207107f);
    gi.Normal( 0.000000f,-0.866025f, 0.500000f); gi.Vertex( 0.000000f,-0.732051f, 1.000000f);
    gi.Normal( 0.000000f,-0.707107f, 0.707107f); gi.Vertex( 0.000000f,-0.414214f, 1.414214f);
    gi.Normal( 0.707107f,-0.612372f, 0.353553f); gi.Vertex( 0.707107f,-0.478398f, 0.853553f);
    gi.Normal( 0.707107f,-0.500000f, 0.500000f); gi.Vertex( 0.707107f,-0.207107f, 1.207107f);
    gi.Normal( 1.000000f, 0.000000f, 0.000000f); gi.Vertex( 1.000000f, 0.133975f, 0.500000f);
    gi.Normal( 1.000000f, 0.000000f, 0.000000f); gi.Vertex( 1.000000f, 0.292893f, 0.707107f);
    gi.End();
    gi.BeginTriangleStrip();
    gi.Normal( 1.000000f, 0.000000f, 0.000000f); gi.Vertex( 1.000000f, 0.292893f, 0.707107f);
    gi.Normal( 1.000000f, 0.000000f, 0.000000f); gi.Vertex( 1.000000f, 0.500000f, 0.866025f);
    gi.Normal( 0.707107f, 0.500000f,-0.500000f); gi.Vertex( 0.707107f, 0.792893f, 0.207107f);
    gi.Normal( 0.707107f, 0.353553f,-0.612372f); gi.Vertex( 0.707107f, 0.853553f, 0.253653f);
    gi.Normal( 0.000000f, 0.707107f,-0.707107f); gi.Vertex( 0.000000f, 1.000000f, 0.000000f);
    gi.Normal( 0.000000f, 0.500000f,-0.866025f); gi.Vertex( 0.000000f, 1.000000f, 0.000000f);
    gi.Normal(-0.707107f, 0.500000f,-0.500000f); gi.Vertex(-0.707107f, 0.792893f, 0.207107f);
    gi.Normal(-0.707107f, 0.353553f,-0.612372f); gi.Vertex(-0.707107f, 0.853553f, 0.253653f);
    gi.Normal(-1.000000f, 0.000000f, 0.000000f); gi.Vertex(-1.000000f, 0.292893f, 0.707107f);
    gi.Normal(-1.000000f, 0.000000f, 0.000000f); gi.Vertex(-1.000000f, 0.500000f, 0.866025f);
    gi.Normal(-0.707107f,-0.500000f, 0.500000f); gi.Vertex(-0.707107f,-0.207107f, 1.207107f);
    gi.Normal(-0.707107f,-0.353553f, 0.612372f); gi.Vertex(-0.707107f, 0.146447f, 1.478398f);
    gi.Normal( 0.000000f,-0.707107f, 0.707107f); gi.Vertex( 0.000000f,-0.414214f, 1.414214f);
    gi.Normal( 0.000000f,-0.500000f, 0.866025f); gi.Vertex( 0.000000f, 0.000000f, 1.732051f);
    gi.Normal( 0.707107f,-0.500000f, 0.500000f); gi.Vertex( 0.707107f,-0.207107f, 1.207107f);
    gi.Normal( 0.707107f,-0.353553f, 0.612372f); gi.Vertex( 0.707107f, 0.146447f, 1.478398f);
    gi.Normal( 1.000000f, 0.000000f, 0.000000f); gi.Vertex( 1.000000f, 0.292893f, 0.707107f);
    gi.Normal( 1.000000f, 0.000000f, 0.000000f); gi.Vertex( 1.000000f, 0.500000f, 0.866025f);
    gi.End();
    gi.BeginTriangleStrip();
    gi.Normal( 1.000000f, 0.000000f, 0.000000f); gi.Vertex( 1.000000f, 0.500000f, 0.866025f);
    gi.Normal( 1.000000f, 0.000000f, 0.000000f); gi.Vertex( 1.000000f, 0.741181f, 0.965926f);
    gi.Normal( 0.707107f, 0.353553f,-0.612372f); gi.Vertex( 0.707107f, 0.853553f, 0.253653f);
    gi.Normal( 0.707107f, 0.183013f,-0.683013f); gi.Vertex( 0.707107f, 0.924194f, 0.282913f);
    gi.Normal( 0.000000f, 0.500000f,-0.866025f); gi.Vertex( 0.000000f, 1.000000f, 0.000000f);
    gi.Normal( 0.000000f, 0.258819f,-0.965926f); gi.Vertex( 0.000000f, 1.000000f, 0.000000f);
    gi.Normal(-0.707107f, 0.353553f,-0.612372f); gi.Vertex(-0.707107f, 0.853553f, 0.253653f);
    gi.Normal(-0.707107f, 0.183013f,-0.683013f); gi.Vertex(-0.707107f, 0.924194f, 0.282913f);
    gi.Normal(-1.000000f, 0.000000f, 0.000000f); gi.Vertex(-1.000000f, 0.500000f, 0.866025f);
    gi.Normal(-1.000000f, 0.000000f, 0.000000f); gi.Vertex(-1.000000f, 0.741181f, 0.965926f);
    gi.Normal(-0.707107f,-0.353553f, 0.612372f); gi.Vertex(-0.707107f, 0.146447f, 1.478398f);
    gi.Normal(-0.707107f,-0.183013f, 0.683013f); gi.Vertex(-0.707107f, 0.558168f, 1.648939f);
    gi.Normal( 0.000000f,-0.500000f, 0.866025f); gi.Vertex( 0.000000f, 0.000000f, 1.732051f);
    gi.Normal( 0.000000f,-0.258819f, 0.965926f); gi.Vertex( 0.000000f, 0.482362f, 1.931852f);
    gi.Normal( 0.707107f,-0.353553f, 0.612372f); gi.Vertex( 0.707107f, 0.146447f, 1.478398f);
    gi.Normal( 0.707107f,-0.183013f, 0.683013f); gi.Vertex( 0.707107f, 0.558168f, 1.648939f);
    gi.Normal( 1.000000f, 0.000000f, 0.000000f); gi.Vertex( 1.000000f, 0.500000f, 0.866025f);
    gi.Normal( 1.000000f, 0.000000f, 0.000000f); gi.Vertex( 1.000000f, 0.741181f, 0.965926f);
    gi.End();
    gi.BeginTriangleStrip();
    gi.Normal( 1.000000f, 0.000000f, 0.000000f); gi.Vertex( 1.000000f, 0.741181f, 0.965926f);
    gi.Normal( 1.000000f, 0.000000f, 0.000000f); gi.Vertex( 1.000000f, 1.000000f, 1.000000f);
    gi.Normal( 0.707107f, 0.183013f,-0.683013f); gi.Vertex( 0.707107f, 0.924194f, 0.282913f);
    gi.Normal( 0.707107f, 0.000000f,-0.707107f); gi.Vertex( 0.707107f, 1.000000f, 0.292893f);
    gi.Normal( 0.000000f, 0.258819f,-0.965926f); gi.Vertex( 0.000000f, 1.000000f, 0.000000f);
    gi.Normal( 0.000000f, 0.000000f,-1.000000f); gi.Vertex( 0.000000f, 1.000000f, 0.000000f);
    gi.Normal(-0.707107f, 0.183013f,-0.683013f); gi.Vertex(-0.707107f, 0.924194f, 0.282913f);
    gi.Normal(-0.707107f, 0.000000f,-0.707107f); gi.Vertex(-0.707107f, 1.000000f, 0.292893f);
    gi.Normal(-1.000000f, 0.000000f, 0.000000f); gi.Vertex(-1.000000f, 0.741181f, 0.965926f);
    gi.Normal(-1.000000f, 0.000000f, 0.000000f); gi.Vertex(-1.000000f, 1.000000f, 1.000000f);
    gi.Normal(-0.707107f,-0.183013f, 0.683013f); gi.Vertex(-0.707107f, 0.558168f, 1.648939f);
    gi.Normal(-0.707107f, 0.000000f, 0.707107f); gi.Vertex(-0.707107f, 1.000000f, 1.707107f);
    gi.Normal( 0.000000f,-0.258819f, 0.965926f); gi.Vertex( 0.000000f, 0.482362f, 1.931852f);
    gi.Normal( 0.000000f, 0.000000f, 1.000000f); gi.Vertex( 0.000000f, 1.000000f, 2.000000f);
    gi.Normal( 0.707107f,-0.183013f, 0.683013f); gi.Vertex( 0.707107f, 0.558168f, 1.648939f);
    gi.Normal( 0.707107f, 0.000000f, 0.707107f); gi.Vertex( 0.707107f, 1.000000f, 1.707107f);
    gi.Normal( 1.000000f, 0.000000f, 0.000000f); gi.Vertex( 1.000000f, 0.741181f, 0.965926f);
    gi.Normal( 1.000000f, 0.000000f, 0.000000f); gi.Vertex( 1.000000f, 1.000000f, 1.000000f);
    gi.End();
}

static void bend_forward ( GraphicInterface & gi )
{
    gi.Translate(0.0, 1.0, 0.0);
    gi.Rotate(90.0, 1.0, 0.0, 0.0);
    gi.Translate(0.0, -1.0, 0.0);
}

static void bend_left ( GraphicInterface & gi )
{
    gi.Rotate(-90.0, 0.0, 0.0, 1.0);
    gi.Translate(0.0, 1.0, 0.0);
    gi.Rotate(90.0, 1.0, 0.0, 0.0);
    gi.Translate(0.0, -1.0, 0.0);
}

static void bend_right ( GraphicInterface & gi )
{
    gi.Rotate(90.0, 0.0, 0.0, 1.0);
    gi.Translate(0.0, 1.0, 0.0);
    gi.Rotate(90.0, 1.0, 0.0, 0.0);
    gi.Translate(0.0, -1.0, 0.0);
}

void logo_dlist ( GraphicInterface & gi )
{
    gi.NewListCompile(DRAW_SINGLE);
    draw_single_cylinder(gi);
    gi.EndList();

    gi.NewListCompile(DRAW_DOUBLE);
    draw_double_cylinder(gi);
    gi.EndList();

    gi.NewListCompile(DRAW_ELBOW);
    draw_elbow(gi);
    gi.EndList();
}

void draw_logo ( GraphicInterface & gi )
{
    gi.Rotate (35.3f, 1.0, 0.0, 0.0);
    gi.Rotate (45.0f, 0.0, 1.0, 0.0);
    gi.Translate(5.5,  -3.5,  4.5);
    gi.Translate(0.0,  0.0,  -7.0);

    gi.CallList(DRAW_DOUBLE);
    bend_forward(gi);
    gi.CallList(DRAW_ELBOW);
    gi.Translate(0.0,  0.0,  -7.0);
    gi.CallList(DRAW_DOUBLE);
    bend_forward(gi);
    gi.CallList(DRAW_ELBOW);
    gi.Translate(0.0,  0.0,  -5.0);
    gi.CallList(DRAW_SINGLE);
    bend_right(gi);
    gi.CallList(DRAW_ELBOW);
    gi.Translate(0.0,  0.0,  -7.0);
    gi.CallList(DRAW_DOUBLE);
    bend_forward(gi);
    gi.CallList(DRAW_ELBOW);
    gi.Translate(0.0,  0.0,  -7.0);
    gi.CallList(DRAW_DOUBLE);
    bend_forward(gi);
    gi.CallList(DRAW_ELBOW);
    gi.Translate(0.0,  0.0,  -5.0);
    gi.CallList(DRAW_SINGLE);
    bend_left(gi);
    gi.CallList(DRAW_ELBOW);
    gi.Translate(0.0,  0.0,  -7.0);
    gi.CallList(DRAW_DOUBLE);
    bend_forward(gi);
    gi.CallList(DRAW_ELBOW);
    gi.Translate(0.0,  0.0,  -7.0);
    gi.CallList(DRAW_DOUBLE);
    bend_forward(gi);
    gi.CallList(DRAW_ELBOW);
    gi.Translate(0.0,  0.0,  -5.0);
    gi.CallList(DRAW_SINGLE);
    bend_right(gi);
    gi.CallList(DRAW_ELBOW);
    gi.Translate(0.0,  0.0,  -7.0);
    gi.CallList(DRAW_DOUBLE);
    bend_forward(gi);
    gi.CallList(DRAW_ELBOW);
    gi.Translate(0.0,  0.0,  -7.0);
    gi.CallList(DRAW_DOUBLE);
    bend_forward(gi);
    gi.CallList(DRAW_ELBOW);
    gi.Translate(0.0,  0.0,  -5.0);
    gi.CallList(DRAW_SINGLE);
    bend_left(gi);
    gi.CallList(DRAW_ELBOW);
    gi.Translate(0.0,  0.0,  -7.0);
    gi.CallList(DRAW_DOUBLE);
    bend_forward(gi);
    gi.CallList(DRAW_ELBOW);
    gi.Translate(0.0,  0.0,  -7.0);
    gi.CallList(DRAW_DOUBLE);
    bend_forward(gi);
    gi.CallList(DRAW_ELBOW);
    gi.Translate(0.0,  0.0,  -5.0);
    gi.CallList(DRAW_SINGLE);
    bend_right(gi);
    gi.CallList(DRAW_ELBOW);
    gi.Translate(0.0,  0.0,  -7.0);
    gi.CallList(DRAW_DOUBLE);
    bend_forward(gi);
    gi.CallList(DRAW_ELBOW);
    gi.Translate(0.0,  0.0,  -7.0);
    gi.CallList(DRAW_DOUBLE);
    bend_forward(gi);
    gi.CallList(DRAW_ELBOW);
    gi.Translate(0.0,  0.0,  -5.0);
    gi.CallList(DRAW_SINGLE);
    bend_left(gi);
    gi.CallList(DRAW_ELBOW);
}
