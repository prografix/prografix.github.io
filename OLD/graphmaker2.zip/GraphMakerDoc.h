// GraphMakerDoc.h : interface of the CGraphMakerDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_GRAPHMAKERDOC_H__C27EB4C5_2C7D_4E9A_86EE_CF6552B430ED__INCLUDED_)
#define AFX_GRAPHMAKERDOC_H__C27EB4C5_2C7D_4E9A_86EE_CF6552B430ED__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CGraphMakerDoc : public CDocument
{
protected: // create from serialization only
	CGraphMakerDoc();
	DECLARE_DYNCREATE(CGraphMakerDoc)

    class GIStorage * data;
// Attributes
public:

// Operations
public:
    void draw();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGraphMakerDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CGraphMakerDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CGraphMakerDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GRAPHMAKERDOC_H__C27EB4C5_2C7D_4E9A_86EE_CF6552B430ED__INCLUDED_)
