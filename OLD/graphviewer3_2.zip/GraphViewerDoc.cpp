// GraphViewerDoc.cpp : implementation of the CGraphViewerDoc class
//

#include "stdafx.h"
#include "gl\gl.h"
#include "GraphViewer.h"
#include "GraphViewerDoc.h"
#include "GraphViewerView.h"
#include "GraphicInterface.h"
#include "CppFileWriter.h"
#include "FileReader.h"
#include "GLDevice.h"
#include "GrClock.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGraphViewerDoc

IMPLEMENT_DYNCREATE(CGraphViewerDoc, CDocument)

BEGIN_MESSAGE_MAP(CGraphViewerDoc, CDocument)
	//{{AFX_MSG_MAP(CGraphViewerDoc)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_COMMAND(ID_FILE_SAVE_AS, OnFileSaveAs)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGraphViewerDoc construction/destruction

CGraphViewerDoc::CGraphViewerDoc()
{
	reader = 0;
    device = 0;
}

CGraphViewerDoc::~CGraphViewerDoc()
{
    delete reader;
    delete device;
}

BOOL CGraphViewerDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CGraphViewerDoc serialization

void CGraphViewerDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CGraphViewerDoc diagnostics

#ifdef _DEBUG
void CGraphViewerDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CGraphViewerDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGraphViewerDoc commands

void CGraphViewerDoc::draw()
{
    if ( reader )
    {
        *reader >> *device;
    }
    else
    {
        glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    }
}

void CGraphViewerDoc::OnFileOpen() 
{
	CFileDialog temp(TRUE,"gra",NULL,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		"Graphical files (*.gra)|*.gra||");
	if ( temp.DoModal() == IDOK )
	{
        OnOpenDocument ( temp.GetPathName() );
    }
}

BOOL CGraphViewerDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
    FileReader * p = reader;
    reader = 0;
    delete p;
    p = new FileReader ( lpszPathName );
	POSITION pos = GetFirstViewPosition();
	while ( pos != NULL )
	{
		CGraphViewerView * pView = (CGraphViewerView*) GetNextView(pos);
        pView->refresh_glContext();
        pView->Invalidate(TRUE);
	}
    delete device;
    device = new GLDevice;
    if ( p->size() > 0 )
    {
        reader = p;
        SetPathName(lpszPathName);
    }
    else
    {
        delete p;
        SetPathName("");
    }
    grClock.begin();
    grClock.forward();
	return reader != 0;
}

void CGraphViewerDoc::OnFileSaveAs() 
{
    if ( reader )
    {
	    CFileDialog temp(FALSE,"cpp",NULL,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		    "C++ files (*.cpp)|*.cpp||");
	    if ( temp.DoModal() == IDOK )
	    {
            CppFileWriter writer ( temp.GetPathName() );
            *reader >> writer;
        }
    }
}
