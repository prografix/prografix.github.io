
//*****************************************************************************
//
//           PseudoFile.h       13.09.2003       Version 2
//
//*****************************************************************************

#ifndef _PSEUDO_FILE_H
#define _PSEUDO_FILE_H

#include "File.h"

class PseudoReadSeekFile : public ReadSeekFile
{
    const char * buf;
    int length, pos;
public:
    PseudoReadSeekFile ( int n, const void * p ) : length(n), buf((const char *)p), pos(0) {}
    int read(void * p, const int size, const int count);
    bool getc(void * p);
    bool seek_set(long offset);
    bool seek_end(long offset);
    bool seek_cur(long offset);
    long tell() { return pos; }
    void rewind () { pos = 0; }
};

class PseudoWriteFile : public WriteFile
{
    Shev::Array<char> & buf;
    int pos;
// ������ ������������ ����� � ��������� ������������:
    PseudoWriteFile ( PseudoWriteFile & );
    void operator = ( PseudoWriteFile & );
public:
    PseudoWriteFile ( Shev::Array<char> & p );
    int write(const void * p, const int size, const int count);
    bool putc(const void * p);
    void flush() {}
    long tell() { return pos; }
};

class PseudoFile : public File
{
    Shev::Array<char> & buf;
    int length, pos;
// ������ ������������ ����� � ��������� ������������:
    PseudoFile ( PseudoFile & );
    void operator = ( PseudoFile & );
public:
    PseudoFile ( int n, Shev::Array<char> & p );
    int read(void * p, const int size, const int count);
    bool getc(void * p);
    int write(const void * p, const int size, const int count);
    bool putc(const void * p);
    void flush() {}
    bool seek_set(long offset);
    bool seek_end(long offset);
    bool seek_cur(long offset);
    void rewind() { pos = 0; }
    long tell() { return pos; }
};

#endif