
//*****************************************************************************
//
//           PseudoFile.cpp       13.09.2003       Version 2
//
//*****************************************************************************

#include "ShevArray.h"
#include "PseudoFile.h"

//*********************************************************************//
//
//                  class PseudoReadSeekFile
//
//*********************************************************************//

int PseudoReadSeekFile::read(void * ptr, const int size, const int count)
{
    if ( size <= 0 || count <= 0 ) return 0;
    int m = ( length - pos ) / size;
    if ( m <= 0 ) return 0;
    if ( m > count ) m = count;
    const int n = size * m;
    char * p = (char *) ptr;
    for ( int i = 0; i < n; ++i ) p[i] = buf[pos++];
    return m;
}

bool PseudoReadSeekFile::getc(void * ptr)
{
    if ( pos >= length ) return false;
    *(char *) ptr = buf[pos++];
    return true;
}

bool PseudoReadSeekFile::seek_cur(long offset)
{
    offset += pos;
    if ( offset < 0 || offset > length ) return false;
    pos = offset;
    return true;
}

bool PseudoReadSeekFile::seek_end(long offset)
{
    offset += length;
    if ( offset < 0 || offset > length ) return false;
    pos = offset;
    return true;
}

bool PseudoReadSeekFile::seek_set(long offset)
{
    if ( offset < 0 || offset > length ) return false;
    pos = offset;
    return true;
}

//*********************************************************************//
//
//                  class PseudoWriteFile
//
//*********************************************************************//

PseudoWriteFile::PseudoWriteFile ( Shev::Array<char> & p ) : buf(p), pos(0)
{
    if ( buf.size() < 1 ) buf.resize ( 512 );
}

int PseudoWriteFile::write(const void * ptr, const int size, const int count)
{
    if ( size <= 0 || count <= 0 ) return 0;
    const int n = size * count;
    while ( pos + n > buf.size() ) buf.resizeAndCopy ( 2*buf.size() );
    const char * p = (const char *) ptr;
    for ( int i = 0; i < n; ++i ) buf[pos++] = p[i];
    return count;
}

bool PseudoWriteFile::putc(const void * ptr)
{
    if ( pos >= buf.size() ) buf.resizeAndCopy ( 2*buf.size() );
    buf[pos++] = *(char *) ptr;
    return true;
}

//********************* 06.01.04 **********************//
//
//                  class PseudoFile
//
//*****************************************************//

PseudoFile::PseudoFile ( int n, Shev::Array<char> & p ) : length(n), buf(p), pos(0)
{
    if ( buf.size() < 1 ) buf.resize ( 512 );
}

int PseudoFile::read(void * ptr, const int size, const int count)
{
    if ( size <= 0 || count <= 0 ) return 0;
    int m = ( length - pos ) / size;
    if ( m <= 0 ) return 0;
    if ( m > count ) m = count;
    const int n = size * m;
    char * p = (char *) ptr;
    for ( int i = 0; i < n; ++i ) p[i] = buf[pos++];
    return m;
}

bool PseudoFile::getc(void * ptr)
{
    if ( pos >= length ) return false;
    *(char *) ptr = buf[pos++];
    return true;
}

bool PseudoFile::seek_cur(long offset)
{
    offset += pos;
    if ( offset < 0 || offset > length ) return false;
    pos = offset;
    return true;
}

bool PseudoFile::seek_end(long offset)
{
    offset += length;
    if ( offset < 0 || offset > length ) return false;
    pos = offset;
    return true;
}

bool PseudoFile::seek_set(long offset)
{
    if ( offset < 0 || offset > length ) return false;
    pos = offset;
    return true;
}

int PseudoFile::write(const void * ptr, const int size, const int count)
{
    if ( size <= 0 || count <= 0 ) return 0;
    const int n = size * count;
    while ( pos + n > buf.size() ) buf.resizeAndCopy ( 2*buf.size() );
    const char * p = (const char *) ptr;
    for ( int i = 0; i < n; ++i ) buf[pos++] = p[i];
    if ( length < pos ) length = pos;
    return count;
}

bool PseudoFile::putc(const void * ptr)
{
    if ( pos >= buf.size() ) buf.resizeAndCopy ( 2*buf.size() );
    buf[pos++] = *(char *) ptr;
    if ( length < pos ) length = pos;
    return true;
}
