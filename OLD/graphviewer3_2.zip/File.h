
//*****************************************************************************
//
//           File.h       13.09.2003       Version 2
//
//*****************************************************************************

#ifndef _FILE_H
#define _FILE_H

class ReadFile
{
public:
    virtual int read(void * p, const int size, const int count) = 0;
    virtual bool getc(void * p) = 0;
    virtual ~ReadFile() {}
};

class WriteFile
{
public:
    virtual int write(const void * p, const int size, const int count) = 0;
    virtual bool putc(const void * p) = 0;
    virtual void flush() = 0;
    virtual ~WriteFile() {}
};

class SeekFile
{
public:
    virtual bool seek_set(long offset) = 0;
    virtual bool seek_end(long offset) = 0;
    virtual bool seek_cur(long offset) = 0;
    virtual void rewind() = 0;
    virtual long tell() = 0;
    virtual ~SeekFile() {}
};

class ReadSeekFile : public ReadFile, public virtual SeekFile {};

class WriteSeekFile : public WriteFile, public virtual SeekFile {};

class File : public ReadSeekFile, public WriteSeekFile {};

#endif