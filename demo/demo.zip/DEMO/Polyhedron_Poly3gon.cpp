
#if 0

#include "Polyhedron_Poly3gon.h"
#include "Vector3f.h"

void copy1 ( const Poly3gon<Vector3f, void> & poly1, Polyhedron & poly2 )
{
    copy ( poly1, poly2 );
}

void copy1 ( const Poly3gon<Vector3d, void> & poly1, Polyhedron & poly2 )
{
    copy ( poly1, poly2 );
}

void copy1 ( const Poly3gon<Vector3f, int> & poly1, Polyhedron & poly2 )
{
    copy ( poly1, poly2 );
}

void copy1 ( const Poly3gon<Vector3d, int> & poly1, Polyhedron & poly2 )
{
    copy ( poly1, poly2 );
}

void copy1 ( const Poly3gon<Vector3f, Vector3f> & poly1, Polyhedron & poly2 )
{
    copy ( poly1, poly2 );
}

void copy1 ( const Poly3gon<Vector3d, Vector3d> & poly1, Polyhedron & poly2 )
{
    copy ( poly1, poly2 );
}

void copy2 ( const Polyhedron & poly1, Poly3gon<Vector3f, void> & poly2 )
{
    copy ( poly1, poly2 );
}

void copy2 ( const Polyhedron & poly1, Poly3gon<Vector3d, void> & poly2 )
{
    copy ( poly1, poly2 );
}

void copy2 ( const Polyhedron & poly1, Poly3gon<Vector3f, int> & poly2 )
{
    copy ( poly1, poly2 );
}

void copy2 ( const Polyhedron & poly1, Poly3gon<Vector3d, int> & poly2 )
{
    copy ( poly1, poly2 );
}

void copy2 ( const Polyhedron & poly1, Poly3gon<Vector3f, Vector3f> & poly2 )
{
    copy ( poly1, poly2 );
}

void copy2 ( const Polyhedron & poly1, Poly3gon<Vector3d, Vector3d> & poly2 )
{
    copy ( poly1, poly2 );
}

#endif