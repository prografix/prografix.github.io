// RandomVec.cpp : implementation file
//

#include "stdafx.h"
#include "DEMO.h"
#include "RandomVec.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// RandomVec dialog


RandomVec::RandomVec(CWnd* pParent /*=NULL*/)
	: CDialog(RandomVec::IDD, pParent)
{
	//{{AFX_DATA_INIT(RandomVec)
	m_nVec = 1000;
	m_max_edge = 0.0;
	m_min_edge = 0.0;
	m_rand_type = 0;
	//}}AFX_DATA_INIT
}


void RandomVec::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(RandomVec)
	DDX_Text(pDX, IDC_NVEC, m_nVec);
	DDX_Text(pDX, IDC_MAX, m_max_edge);
	DDX_Text(pDX, IDC_MIN, m_min_edge);
	DDX_CBIndex(pDX, IDC_COMBO_RAND, m_rand_type);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(RandomVec, CDialog)
	//{{AFX_MSG_MAP(RandomVec)
	ON_BN_CLICKED(ID_RUN, OnRun)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// RandomVec message handlers

#include "math.h"
#include "rand.h"
#include "func3d.h"
#include "DEMODoc.h"
#include "DEMOView.h"
#include "ShevArray.h"

void RandomVec::OnRun() 
{
	UpdateData();
    if ( m_nVec < 10 )
    {
        m_nVec = 10;
	    UpdateData(FALSE);
    }
    else
    if ( m_nVec > 90000 )
    {
        m_nVec = 90000;
	    UpdateData(FALSE);
    }
    DynArray<Vector3d> v ( m_nVec );
    if ( m_rand_type == 0 )
    {
        v << QRandVector3d();
    }
    else
    {
        v << PRandVector3d();
    }
    convexHull ( v, poly );

	m_max_edge = 0.0;
	m_min_edge = 1e300;
    for ( nat i = 0; i < poly.facet.size(); ++i )
    {
        const Facet & f = poly.facet[i];
        CArrRef<nat> p = f.index;
        for ( nat j = 0; j < f.nv; ++j )
        {
            double t = sqrt ( qmod ( poly.vertex[p[j]] - poly.vertex[p[j+1]] ) );
            if ( m_max_edge < t ) m_max_edge = t;
            if ( m_min_edge > t ) m_min_edge = t;
        }
    }
    if ( m_min_edge == 1e300 ) m_min_edge = 0.;
	UpdateData(FALSE);

    CDEMODoc * doc = view->GetDocument();
    _swap ( doc->poly, poly );
    doc->drawPolyhedron();
    view->Invalidate(TRUE);
}
