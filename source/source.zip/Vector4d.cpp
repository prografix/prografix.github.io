
#include <math.h>
#include "LinAlg.h"
#include "Vector4d.h"
#include "DoubleN.h"

//**************************** 22.04.2019 *********************************//
//
//                ����������� ������ ���������������
//
//**************************** 22.04.2019 *********************************//

Def<Vector4d> intersection ( const Plane4d & plane1, const Plane4d & plane2, const Plane4d & plane3, const Plane4d & plane4 )
{
    SLU4<double> slu;
    slu.aa = plane1.norm.x1;   slu.ab = plane1.norm.x2;   slu.ac = plane1.norm.x3;   slu.ad = plane1.norm.x4;   slu.ae = -plane1.dist;
    slu.ba = plane2.norm.x1;   slu.bb = plane2.norm.x2;   slu.bc = plane2.norm.x3;   slu.bd = plane2.norm.x4;   slu.be = -plane2.dist;
    slu.ca = plane3.norm.x1;   slu.cb = plane3.norm.x2;   slu.cc = plane3.norm.x3;   slu.cd = plane3.norm.x4;   slu.ce = -plane3.dist;
    slu.da = plane4.norm.x1;   slu.db = plane4.norm.x2;   slu.dc = plane4.norm.x3;   slu.dd = plane4.norm.x4;   slu.de = -plane4.dist;
    Def<Vector4d> point;
    point.isDef = slu.gauss ( point.x1, point.x2, point.x3, point.x4 );
    return point;
}


//************************ 28.04.2019 *******************************//
//
//      ���������� ��������� ����� � �������� ����������
//      ������� ������������� ���������� ( ����������� ����� )
//
//************************ 28.04.2019 *******************************//

Def<Vector4d> getNearPointU ( CCArrRef<Plane4d> & plane )
{
    Def<Vector4d> res;
    const nat nn = plane.size();
    if ( nn < 4 ) return res;
    nat i1 = 0, i2 = 1, i3 = 2, i4 = 3, i5 = 4;
    Def<Vector4d> p5 = intersection ( plane[i1], plane[i2], plane[i3], plane[i4] );
    if ( ! p5.isDef || nn == 4 ) return p5;
    if ( nn > 5 )
    {
        double max = fabs ( plane[i5] % p5 );
        for ( nat i = 5; i < nn; ++i )
        {
            const double t = fabs ( plane[i] % res );
            if ( max < t ) max = t, i5 = i;
        }
    }
    Def<Vector4d> p1 = intersection ( plane[i5], plane[i2], plane[i3], plane[i4] );
    if ( ! p1.isDef ) return p1;
    Def<Vector4d> p2 = intersection ( plane[i1], plane[i5], plane[i3], plane[i4] );
    if ( ! p2.isDef ) return p2;
    Def<Vector4d> p3 = intersection ( plane[i1], plane[i2], plane[i5], plane[i4] );
    if ( ! p3.isDef ) return p3;
    Def<Vector4d> p4 = intersection ( plane[i1], plane[i2], plane[i3], plane[i5] );
    if ( ! p4.isDef ) return p4;
    const Plane4d plane1 = plane[i1] % p1 > 0 ? plane[i1] : - plane[i1];
    const Plane4d plane2 = plane[i2] % p2 > 0 ? plane[i2] : - plane[i2];
    const Plane4d plane3 = plane[i3] % p3 > 0 ? plane[i3] : - plane[i3];
    const Plane4d plane4 = plane[i4] % p4 > 0 ? plane[i4] : - plane[i4];
    const Plane4d plane5 = plane[i5] % p5 > 0 ? plane[i5] : - plane[i5];
    SLU4<double> slu;
    slu.aa = plane1.norm.x1 - plane5.norm.x1;
    slu.ab = plane1.norm.x2 - plane5.norm.x2;
    slu.ac = plane1.norm.x3 - plane5.norm.x3;
    slu.ad = plane1.norm.x4 - plane5.norm.x4;
    slu.ae = plane5.dist - plane1.dist;
    slu.ba = plane2.norm.x1 - plane5.norm.x1;
    slu.bb = plane2.norm.x2 - plane5.norm.x2;
    slu.bc = plane2.norm.x3 - plane5.norm.x3;
    slu.bd = plane2.norm.x4 - plane5.norm.x4;
    slu.be = plane5.dist - plane2.dist;
    slu.ca = plane3.norm.x1 - plane5.norm.x1;
    slu.cb = plane3.norm.x2 - plane5.norm.x2;
    slu.cc = plane3.norm.x3 - plane5.norm.x3;
    slu.cd = plane3.norm.x4 - plane5.norm.x4;
    slu.ce = plane5.dist - plane3.dist;
    slu.da = plane4.norm.x1 - plane5.norm.x1;
    slu.db = plane4.norm.x2 - plane5.norm.x2;
    slu.dc = plane4.norm.x3 - plane5.norm.x3;
    slu.dd = plane4.norm.x4 - plane5.norm.x4;
    slu.de = plane5.dist - plane4.dist;
    res.isDef = slu.gauss ( res.x1, res.x2, res.x3, res.x4 );
    if ( ! res.isDef || nn == 5 )
        return res;
    double dist = plane5 % res;
    if ( dist <= 0 )
        return res;
    Double<5> arr[6];
    arr[0].d0 = arr[1].d0 = arr[2].d0 = arr[3].d0 = arr[4].d0 = dist;
    arr[0].d1 = res.x1;
    arr[0].d2 = res.x2;
    arr[0].d3 = res.x3;
    arr[0].d4 = res.x4;
    arr[1].d1 = res.x1 - p1.x1;
    arr[1].d2 = res.x2 - p1.x2;
    arr[1].d3 = res.x3 - p1.x3;
    arr[1].d4 = res.x4 - p1.x4;
    arr[2].d1 = res.x1 - p2.x1;
    arr[2].d2 = res.x2 - p2.x2;
    arr[2].d3 = res.x3 - p2.x3;
    arr[2].d4 = res.x4 - p2.x4;
    arr[3].d1 = res.x1 - p3.x1;
    arr[3].d2 = res.x2 - p3.x2;
    arr[3].d3 = res.x3 - p3.x3;
    arr[3].d4 = res.x4 - p3.x4;
    arr[4].d1 = res.x1 - p4.x1;
    arr[4].d2 = res.x2 - p4.x2;
    arr[4].d3 = res.x3 - p4.x3;
    arr[4].d4 = res.x4 - p4.x4;
    arr[5].d1 = res.x1 - p5.x1;
    arr[5].d2 = res.x2 - p5.x2;
    arr[5].d3 = res.x3 - p5.x3;
    arr[5].d4 = res.x4 - p5.x4;
    // ������������ ��������
    for ( nat i = 1; i < 6; ++i )
    {
        Double<5> & d = arr[i];
        d *= 1 / sqrt ( d * d );
    }
    for ( nat k = 0; k < nn; ++k )
    {
        nat i, im = 0;
        double max = fabs ( plane[0] % res );
        for ( i = 1; i < nn; ++i )
        {
            const double t = fabs ( plane[i] % res );
            if ( max < t ) max = t, im = i;
        }
        if ( max <= ( 1 + 1e-12 ) * dist )
            return res;
        dist = max - dist;
        Plane4d pm = plane[im];
        if ( pm % res > 0 ) pm = - pm;
        Double<5> cor;
        cor.init ( 1, pm.norm.x1, pm.norm.x2, pm.norm.x3, pm.norm.x4 );
        nat ib = 0;
        double sm = 0; // ��� ������������
        for ( i = 1; i < 6; ++i )
        {
            const Double<5> & v = arr[i];
            double t = cor * v;
            if ( t < 1e-12 ) continue;
            t = 1./ t;
            if ( ib == 0 )
            {
                max = v.d0 * t;
                ib = i;
                sm = t;
            }
            else
            {
                const double u = v.d0 * t;
                if ( u < max ) max = u, ib = i, sm = t;
            }
        }
        if ( ib == 0 ) 
            break;
        const Double<5> & v = arr[ib];
        Double<5> & a0 = arr[0];
        a0 += v * ( dist * sm );
        res.x1 = a0.d1;
        res.x2 = a0.d2;
        res.x3 = a0.d3;
        res.x4 = a0.d4;
        dist = a0.d0;
        for ( i = 1; i < 6; ++i )
        {
            if ( i == ib ) continue;
            Double<5> & ai = arr[i];
            ai -= v * ( ( cor * ai ) * sm );
            ai *= ( 1./ sqrt ( ai * ai ) );
        }
    }
    return Def<Vector4d>();
}