
#include "LinAlg.h"
#include "Vector4d.h"

//**************************** 22.04.2019 *********************************//
//
//                ����������� ������ ���������������
//
//**************************** 22.04.2019 *********************************//

Def<Vector4d> intersection ( const Plane4d & plane1, const Plane4d & plane2, const Plane4d & plane3, const Plane4d & plane4 )
{
    SLU4<double> slu;
    slu.aa = plane1.norm.x1;   slu.ab = plane1.norm.x2;   slu.ac = plane1.norm.x3;   slu.ad = plane1.norm.x4;   slu.ae = -plane1.dist;
    slu.ba = plane2.norm.x1;   slu.bb = plane2.norm.x2;   slu.bc = plane2.norm.x3;   slu.bd = plane2.norm.x4;   slu.be = -plane2.dist;
    slu.ca = plane3.norm.x1;   slu.cb = plane3.norm.x2;   slu.cc = plane3.norm.x3;   slu.cd = plane3.norm.x4;   slu.ce = -plane3.dist;
    slu.da = plane4.norm.x1;   slu.db = plane4.norm.x2;   slu.dc = plane4.norm.x3;   slu.dd = plane4.norm.x4;   slu.de = -plane4.dist;
    Def<Vector4d> point;
    point.isDef = slu.gauss ( point.x1, point.x2, point.x3, point.x4 );
    return point;
}