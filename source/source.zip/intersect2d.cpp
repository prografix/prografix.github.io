
#include "math.h"
#include "lists.h"
#include "func1t.h"
#include "func2d.h"
#include "opti2d.h"
#include "ShevArray.h"
#include "intersect2d.h"
#include "ageom.h"

//**************************** 08.03.2011 *********************************//
//
//               ����������� ����� � ��������������
//
//**************************** 28.03.2011 *********************************//

bool isIntersect ( const Vector2d & p, CArrRef<Vector2d> poly )
{
    const nat n = poly.size();
    if ( n <= 1 ) return n > 0 ? p == poly[0] : false;
    bool res = false;
    const Vector2d & v1 = poly.las();
    double x1 = p.x - v1.x;
    double y1 = p.y - v1.y;
    for ( nat i = 0; i < n; ++i )
    {
        const Vector2d & v2 = poly[i];
        const double x2 = p.x - v2.x;
        const double y2 = p.y - v2.y;
        if ( y1 == 0 && ( x1 == 0 || ( y2 == 0 && x1 > 0 != x2 > 0 ) ) ) return true;
        if ( y1 > 0 != y2 > 0 )
        {
            const double d = x1 - y1 * ( x1 - x2 ) / ( y1 - y2 );
            if ( d == 0 ) return true;
            if ( d > 0 ) res = ! res;
        }
        x1 = x2;
        y1 = y2;
    }
    return res;
}

//**************************** 08.09.2006 *********************************//
//
//                      ����������� ���� ������
//
//**************************** 23.05.2010 *********************************//

Def<Vector2d> intersection ( const Line2d & line1, const Line2d & line2 )
{
    Def<Vector2d> point;
    const double d = line1.norm % line2.norm;
    if ( d == 0 ) return point;
    point.x = ( line1.norm.y * line2.dist - line2.norm.y * line1.dist ) / d; 
    point.y = ( line2.norm.x * line1.dist - line1.norm.x * line2.dist ) / d;
    point.isDef = true;
    return point;
}

//**************************** 13.10.2010 *********************************//
//
//                      ����������� ������ � �������
//
//**************************** 13.10.2010 *********************************//

Def<Vector2d> intersection ( const Line2d & line, const Segment2d & seg )
{
    Def<Vector2d> p;
    const double a = line % seg.a;
    const double b = line % seg.b;
    if ( a * b > 0 || a == b ) return p;
    if ( fabs ( line.norm.x ) > fabs ( line.norm.y ) )
    {
        p.y = ( seg.a.y * b - seg.b.y * a ) / ( b - a );
        p.x = - ( line.norm.y * p.y + line.dist ) / line.norm.x;
    }
    else
    {
        p.x = ( seg.a.x * b - seg.b.x * a ) / ( b - a );
        p.y = - ( line.norm.x * p.x + line.dist ) / line.norm.y;
    }
    p.isDef = true;
    return p;
}

//**************************** 16.10.2010 *********************************//
//
//                      ����������� ���� ��������
//
//**************************** 16.10.2010 *********************************//

Def<Vector2d> intersection ( const Segment2d & s1, const Segment2d & s2 )
{
    Def<Vector2d> p;
    const Vector2d v1 = s1.b - s1.a;
    const Vector2d v2 = s2.b - s2.a;
    const double d = v1 % v2;
    if ( d == 0 ) return p;
    const Vector2d vv = s1.a - s2.a;
    const double t1 = ( v2 % vv ) / d;
    if ( t1 < 0 || t1 > 1 ) return p;
    const double t2 = ( v1 % vv ) / d;
    if ( t2 < 0 || t2 > 1 ) return p;
    p = t1 < t2 ? s1.a + v1 * t1 : s2.a + v2 * t2;
    return p;
}

//**************************** 18.05.2008 *********************************//
//
//                  ��������� ������ ����� �������
//
//**************************** 18.10.2010 *********************************//

Def<Segment2d> cut ( const Line2d & line, const Segment2d & seg )
{
    Def<Segment2d> res ( seg );
    const double a = line % res.a;
    const double b = line % res.b;
    if ( a < 0 )
    {
        if ( b > 0 )
        {
            const double c = b - a;
            if ( fabs ( line.norm.x ) > fabs ( line.norm.y ) )
            {
                res.b.y = ( res.a.y * b - res.b.y * a ) / c;
                res.b.x = - ( line.norm.y * res.b.y + line.dist ) / line.norm.x;
            }
            else
            {
                res.b.x = ( res.a.x * b - res.b.x * a ) / c;
                res.b.y = - ( line.norm.x * res.b.x + line.dist ) / line.norm.y;
            }
        }
    }
    else
    {
        if ( b >= 0 )
        {
            res.isDef = false;
            return res;
        }
        const double c = b - a;
        if ( fabs ( line.norm.x ) > fabs ( line.norm.y ) )
        {
            res.a.y = ( res.a.y * b - res.b.y * a ) / c;
            res.a.x = - ( line.norm.y * res.a.y + line.dist ) / line.norm.x;
        }
        else
        {
            res.a.x = ( res.a.x * b - res.b.x * a ) / c;
            res.a.y = - ( line.norm.x * res.a.x + line.dist ) / line.norm.y;
        }
    }
    return res;
}

//**************************** 27.11.2010 *********************************//
//
//                  ����������� ������ � �����
//
//**************************** 11.12.2010 *********************************//

Def<Segment2d> intersection ( const Line2d & line, const Circle2d & cir )
{
    Def<Segment2d> res;
    const double u = norm2 ( line.norm );
    if ( u == 0 ) return res;
    const double d = ( line % cir.o ) / u;
    if ( fabs ( d ) > cir.r ) return res;
    const Vector2d norm = line.norm / u;
    const Vector2d v = cir.o - d * norm;
    const Vector2d p = norm.leftPerpendicular();
    const double s = sqrt ( cir.r * cir.r - d * d );
    res.a = v - s * p;
    res.b = v + s * p;
    res.isDef = true;
    return res;
}

//**************************** 27.11.2010 *********************************//
//
//                  ����������� ������� � �����
//
//**************************** 21.02.2026 *********************************//

Def<Segment2d> intersection ( const Segment2d & seg, const Circle2d & cir )
{
    Def<Segment2d> res;
    const Vector2d u = cir.o - seg.a;
    const Vector2d v = seg.b - seg.a;
    const double a = v * v;
    const double b = v * u;
    const double c = u * u - cir.r * cir.r;
    if ( a == 0 )
    {
        return c > 0 ? res : ( res = seg );
    }
    double d = b * b - a * c;
    if ( d < 0 ) return res;
    d = sqrt ( d );
    const double t1 = ( b - d ) / a;
    if ( t1 > 1 ) return res;
    const double t2 = ( b + d ) / a;
    if ( t2 < 0 ) return res;
    res.a = t1 > 0 ? seg.a + t1 * v : seg.a;
    res.b = t2 < 1 ? seg.a + t2 * v : seg.b;
    res.isDef = true;
    return res;
}

//**************************** 11.12.2010 *********************************//
//
//                  ����������� ������ � �������
//
//**************************** 11.12.2010 *********************************//

Def<Segment2d> intersection ( const Line2d & line, const Ellipse2d & e )
{
    Def<Segment2d> res;
    const Affin2d af = e.getAffin2d();
    Line2d tmp;
    tmp.norm.x = line.norm.x * af.t.x.x + line.norm.y * af.t.y.x;
    tmp.norm.y = line.norm.x * af.t.x.y + line.norm.y * af.t.y.y;
    tmp.dist = line % af.s;
    res = intersection ( tmp, Circle2d ( null2d, 1 ) );
    if ( ! res.isDef ) return res;
    res.a = af ( res.a );
    res.b = af ( res.b );
    return res;
}

//**************************** 11.12.2010 *********************************//
//
//                  ����������� ������� � �������
//
//**************************** 11.12.2010 *********************************//

Def<Segment2d> intersection ( const Segment2d & seg, const Ellipse2d & e )
{
    Def<Segment2d> res;
    const Affin2d af1 = e.getAffin2d();
    const Def<Affin2d> af2 = ~af1;
    if ( ! af2.isDef )
        return res;
    res = intersection ( Segment2d ( af2 ( seg.a ), af2 ( seg.b ) ), Circle2d ( null2d, 1 ) );
    if ( ! res.isDef )
        return res;
    res.a = af1 ( res.a );
    res.b = af1 ( res.b );
    return res;
}

//**************************** 08.01.2011 *********************************//
//
//               ����������� ������ � ��������������
//
//**************************** 08.01.2011 *********************************//

DynArrRef<Segment2d> & intersection ( const Line2d & line, CArrRef<Vector2d> poly, DynArrRef<Segment2d> & res )
{
    const nat n = poly.size();
    if ( n < 2 || ! line.norm )
        return res.resize();
    const nat n2 = n / 2;
    DynArray<SortItem<double, Vector2d> > arr ( n );
    LtdSuiteRef<SortItem<double, Vector2d> > v1 ( arr,  0, n2 ), v2 ( arr, n2, n2 );
    DynArray<double> d ( n );
    nat i;
    for ( i = 0; i < n; ++i )
    {
        d[i] = line % poly[i];
    }
    for ( i = 0; i < n; ++i )
    {
        const Vector2d & va = poly.cprev(i);
        const Vector2d & vb = poly[i];
        const double a = d.cprev(i);
        const double b = d[i];
        const double c = a * b;
        if ( c > 0 ) continue;
        if ( c < 0 )
        {
            SortItem<double, Vector2d> & si = a < 0 ? v1.inc() : v2.inc();
            si.tail = va + ( vb - va ) * ( a / ( a - b ) );
            si.head = line.norm % si.tail;
        }
        else
        {
            if ( a == 0 )
            {
                if ( b >= 0 || d.cprev(i>0?i-1:n-1) < 0 ) continue;
                SortItem<double, Vector2d> & si = v2.inc();
                si.tail = va;
                si.head = line.norm % si.tail;
            }
            else
            {
                if ( a >= 0 || d.cnext(i) < 0 ) continue;
                SortItem<double, Vector2d> & si = v1.inc();
                si.tail = vb;
                si.head = line.norm % si.tail;
            }
        }
    }
    if ( v1.size() != v2.size() )
        return res;
    if ( v1.size() > 1 )
    {
        quickSort123 ( v1 );
        quickSort123 ( v2 );
    }
    res.resize ( v1.size() );
    for ( i = 0; i < v1.size(); ++i )
    {
        res[i].a = v1[i].tail;
        res[i].b = v2[i].tail;
    }
    return res;
}

//**************************** 08.01.2011 *********************************//
//
//               ����������� ������� � ��������������
//
//**************************** 08.01.2011 *********************************//

SuiteRef<Segment2d> & intersection ( const Segment2d & seg, CArrRef<Vector2d> poly, SuiteRef<Segment2d> & res )
{
    res.resize();
    const Line2d line ( seg.a, seg.b );
    const double a = line.norm % seg.a;
    const double b = line.norm % seg.b;
    DynArray<Segment2d> sec;
    intersection ( poly, line, sec );
    for ( nat i = 0; i < sec.size(); ++i )
    {
        double ai = line.norm % sec[i].a;
        double bi = line.norm % sec[i].b;
        if ( ai > bi )
        {
            _swap ( ai, bi );
            _swap ( sec[i].a, sec[i].b );
        }
        if ( bi <= a || ai >= b ) continue;
        Segment2d & s = res.inc();
        s.a = ai > a ? sec[i].a : seg.a;
        s.b = bi < b ? sec[i].b : seg.b;
    }
    return res;
}

//**************************** 20.08.2026 *********************************//
//
//               ��������� ������������� ����� ��������������
//
//**************************** 26.08.2026 *********************************//

class CutGuru2d : public ICutPolygonGuru
{
    Suite<int> status;
    DynArray<double> dist;
    Suite<Vector2d> poly;
    const Line2d line;
public:
    virtual CCArrRef<int> & getStatus ()  { return status; }
    virtual void arrange ( ArrRef<nat> & in, ArrRef<nat> & out )
    {
        nat i;
        const nat m = in.size();
        CmbArray<SortItem<double, nat>, 8> arr2 ( m+m );
        ArrRef<SortItem<double, nat> > s1 ( arr2, 0, m ), s2 ( arr2, m, m );
        for ( i = 0; i < m; ++i )
        {
            s1[i].head = line.norm % poly[in[i]];
            s1[i].tail = i;
            s2[i].head = line.norm % poly[out[i]];
            s2[i].tail = i;
        }
        insertSort123 ( s1 );
        insertSort123 ( s2 );
        for ( i = 0; i < m; ++i )
        {
            in [i] = s1[i].tail;
            out[i] = s2[i].tail;
        }
    }
    virtual nat newVert ( nat ia, nat ib )
    {
        const Vector2d & va = poly[ia];
        const Vector2d & vb = poly[ib];
        const double da = dist[ia];
        const double db = dist[ib];
        Vector2d p;
        if ( fabs ( line.norm.x ) > fabs ( line.norm.y ) )
        {
            p.y = fabs ( da ) < fabs ( db ) ? 
                va.y + ( va.y - vb.y ) * da / ( db - da ) : 
                vb.y + ( vb.y - va.y ) * db / ( da - db );
            p.x = - ( line.norm.y * p.y + line.dist ) / line.norm.x;
        }
        else
        {
            p.x = fabs ( da ) < fabs ( db ) ? 
                va.x + ( va.x - vb.x ) * da / ( db - da ) : 
                vb.x + ( vb.x - va.x ) * db / ( da - db );
            p.y = - ( line.norm.x * p.x + line.dist ) / line.norm.y;
        }
        const nat n = poly.size();
        poly.inc() = p;
        return n;
    }

    CutGuru2d ( CCArrRef<Vector2d> & p, const Line2d & l ) : line(l)
    {
        const nat nv = p.size();
        poly = p;
        dist.resize ( nv );
        status.resize ( nv );
        for ( nat i = 0; i < nv; ++i )
        {
            const double d = dist[i] = line % poly[i];
            status[i] = d < 0 ? -1 : d > 0 ? 1 : 0;
        }
    }
    CCArrRef<Vector2d> & getVert() { return poly; }
};

bool cutPolygon ( CCArrRef<Vector2d> & poly, const Line2d & line, DynArrRef< DynArray<Vector2d> > & res )
{
    Suite< Suite<nat> > temp;
    CutGuru2d guru ( poly, line );
    if ( ! cutPolygon ( guru, temp ) )
        return false;
    CCArrRef<Vector2d> & vert = guru.getVert();
    const nat np = temp.size();
    res.resize ( np );
    for ( nat i = 0; i < np; ++i )
    {
        CCArrRef<nat> & ii = temp[i];
        DynArray<Vector2d> & pi = res[i];
        const nat n = ii.size();
        pi.resize ( n );
        for ( nat j = 0; j < n; ++j ) pi[j] = vert[ii[j]];
    }
    return true;
}

//**************************** 20.08.2026 *********************************//
//
//               ���������� �������������� �� ��� �����
//
//**************************** 26.08.2026 *********************************//

bool cutPolygon ( CCArrRef<Vector2d> & poly, const Line2d & line, DynArrRef< DynArray<Vector2d> > & plus, DynArrRef< DynArray<Vector2d> > & minus )
{
    Suite< Suite<nat> > ptemp, mtemp;
    CutGuru2d guru ( poly, line );
    if ( ! cutPolygon ( guru, ptemp, mtemp ) )
        return false;
    CCArrRef<Vector2d> & vert = guru.getVert();
    const nat nm = mtemp.size();
    minus.resize ( nm );
    for ( nat i = 0; i < nm; ++i )
    {
        CCArrRef<nat> & ii = mtemp[i];
        DynArray<Vector2d> & pi = minus[i];
        const nat n = ii.size();
        pi.resize ( n );
        for ( nat j = 0; j < n; ++j ) pi[j] = vert[ii[j]];
    }
    const nat np = ptemp.size();
    plus.resize ( np );
    for ( nat i = 0; i < np; ++i )
    {
        CCArrRef<nat> & ii = ptemp[i];
        DynArray<Vector2d> & pi = plus[i];
        const nat n = ii.size();
        pi.resize ( n );
        for ( nat j = 0; j < n; ++j ) pi[j] = vert[ii[j]];
    }
    return true;
}

//**************************** 31.08.2026 *********************************//
//
//            ����������� ���� �������� ���������������
//
//**************************** 31.08.2026 *********************************//

inline int areaSign ( const Vector2d & a, const Vector2d & b, const Vector2d & c )
{
    const double d = ( b - a ) % ( c - a );
    return d > 0 ? 1 : d < 0 ? -1 : 0;
}

inline void addVert ( SuiteRef<Vector2d> & p, const Vector2d & v )
{
    if ( p.size() == 0 || p.las() != v ) p.inc() = v;
}

inline nat advanceVert ( nat i, nat & cnt, nat n, bool inside, const Vector2d & v, SuiteRef<Vector2d> & r )
{
    if ( inside ) addVert ( r, v );
    ++cnt;
    return i + 1 < n ? i + 1 : 0;
}

static bool insideConv ( const Vector2d & p, CCArrRef<Vector2d> & poly )
{
    const nat n = poly.size();
    for ( nat i = 0; i < n; ++i )
    {
        const Vector2d & a = poly.cprev(i);
        const Vector2d & b = poly[i];
        if ( ( b - a ) % ( p - a ) < 0 ) return false;
    }
    return true;
}

SuiteRef<Vector2d> & intersect2c ( CCArrRef<Vector2d> & p1, CCArrRef<Vector2d> & p2, SuiteRef<Vector2d> & res )
{
    res.resize();
    const nat n = p1.size();
    const nat m = p2.size();
    if ( n < 3 || m < 3 )
        return res;
    nat a = 0, b = 0, aa = 0, ba = 0;
    int inflag = 0;
    bool firstPoint = true;
    Vector2d first;
    const nat n2 = n + n;
    const nat m2 = m + m;
    while ( ( aa < n || ba < m ) && aa < n2 && ba < m2 )
    {
        const nat a1 = a > 0 ? a - 1 : n - 1;
        const Vector2d v1 = p1[a] - p1[a1];
        if ( ! v1 )
        {
            a = advanceVert ( a, aa, n, false, p1[a], res );
            continue;
        }
        const nat b1 = b > 0 ? b - 1 : m - 1;
        const Vector2d v2 = p2[b] - p2[b1];
        if ( ! v2 )
        {
            b = advanceVert ( b, ba, m, false, p2[b], res );
            continue;
        }
        const int cross = areaSign ( null2d, v1, v2 );
        const int aHB = areaSign ( p2[b1], p2[b], p1[a] );
        const int bHA = areaSign ( p1[a1], p1[a], p2[b] );
        const Def<Vector2d> ip = intersection ( Segment2d ( p1[a1], p1[a] ), Segment2d ( p2[b1], p2[b] ) );
        int code = ip.isDef ? 1 : 0;
        if ( ! code && cross == 0 && ( p2[b1] - p1[a1] ) % v1 == 0 )
        {
            const double t0 = v1 * p1[a1];
            const double t1 = v1 * p1[a];
            const double u0 = v1 * p2[b1];
            const double u1 = v1 * p2[b];
            if ( _min ( t0, t1 ) <= _max ( u0, u1 ) && _min ( u0, u1 ) <= _max ( t0, t1 ) )
                code = 2;
        }
        if ( code == 1 )
        {
            if ( inflag == 0 && firstPoint )
            {
                aa = ba = 0;
                firstPoint = false;
                first = ip;
            }
            else if ( ! firstPoint && ip == first && res.size() > 0 )
            {
                break;
            }
            addVert ( res, ip );
            if ( aHB > 0 ) inflag = 1;
            else if ( bHA > 0 ) inflag = 2;
        }
        if ( code == 2 && v1 * v2 < 0 )
        {
            res.resize();
            break;
        }
        if ( cross == 0 && aHB < 0 && bHA < 0 )
        {
            res.resize();
            break;
        }
        if ( cross == 0 && aHB == 0 && bHA == 0 )
        {
            if ( inflag == 1 )
                b = advanceVert ( b, ba, m, inflag == 2, p2[b], res );
            else
                a = advanceVert ( a, aa, n, inflag == 1, p1[a], res );
        }
        else if ( cross >= 0 )
        {
            if ( bHA > 0 )
                a = advanceVert ( a, aa, n, inflag == 1, p1[a], res );
            else
                b = advanceVert ( b, ba, m, inflag == 2, p2[b], res );
        }
        else
        {
            if ( aHB > 0 )
                b = advanceVert ( b, ba, m, inflag == 2, p2[b], res );
            else
                a = advanceVert ( a, aa, n, inflag == 1, p1[a], res );
        }
    }
    if ( firstPoint )
    {
        if ( area ( p1 ) < area ( p2 ) )
        {
            Vector2d o = null2d;
            o += p1;
            o /= p1.size();
            if ( insideConv ( o, p2 ) )
                res = p1;
        }
        else
        {
            Vector2d o = null2d;
            o += p2;
            o /= p2.size();
            if ( insideConv ( o, p1 ) )
                res = p2;
        }
    }
    else
    {
        if ( res.size() > 2 && res.las() == res[0] ) res.dec();
        if ( res.size() < 3 ) res.resize();
    }
    return res;
}

//**************************** 28.01.2011 *********************************//
//
//            ����������� ��������� �������������� � �������
//
//**************************** 28.08.2026 *********************************//

Suite< DynArray<Vector2d> > & 
intersect1c ( CCArrRef<Vector2d> & conv, CCArrRef<Vector2d> & poly, Suite< DynArray<Vector2d> > & res )
{
    res.resize();
    const nat n = conv.size();
    if ( n < 3 ) return res;
    res.inc() = poly;
    bool none = true;
    Suite< DynArray<Vector2d> > tmp, one;
    for ( nat i = 0; i < conv.size(); ++i )
    {
        const Vector2d & a = conv.cprev(i);
        const Vector2d & b = conv[i];
        if ( a == b ) continue;
        none = false;
        const Line2d line ( a, b );
        tmp.resize();
        for ( nat j = 0; j < res.size(); ++j )
        {
            if ( ! cutPolygon ( res[j], line, one ) ) continue;
            for ( nat k = 0; k < one.size(); ++k ) tmp.inc() = one[k];
        }
        _swap ( res, tmp );
    }
    if ( none ) res.dec();
    return res;
}

//**************************** 23.05.2012 *********************************//
//
//             ����������� ���� ������� ���������������
//
//**************************** 11.06.2026 *********************************//

inline void put ( Suite<Vector2d> & p, const Vector2d & v )
{
    if ( p.size() == 0 || p.las() != v ) p.inc() = v;
}

inline void intersect1c ( CCArrRef<Vector2d> & poly1, CCArrRef<Vector2d> & poly2, Suite< Suite<Vector2d> > & res )
{
    Suite< DynArray<Vector2d> > tmp;
    intersect1c ( poly1, poly2, tmp );
    res.resize ( tmp.size() );
    for ( nat i = 0; i < tmp.size(); ++i ) res[i] = tmp[i];
}

static bool intersection ( ArrRef<Vector2d> & poly1, ArrRef<Vector2d> & poly2, Suite< Suite<Vector2d> > & res )
{
    nat i, j;
    res.resize();
    if ( poly1.size() < 3 || poly2.size() < 3 ) return true;
// ��������� ������� ���������������
    double area1 = area ( poly1 );
    double area2 = area ( poly2 );
    if ( area1 == 0 || area2 == 0 ) return true;
// ���� �����-�� �� ��������������� ��������, �� ��������� ����������� ��������� �����������
    if ( area1 > 0 && area2 > 0 )
    {
        if ( isConvex ( poly1 ) )
        {
            if ( isConvex ( poly2 ) )
            {
                res.resize(1);
                intersect2c ( poly1, poly2, res[0] );
                if ( ! res[0].size() )
                    res.resize();
            }
            else
                intersect1c ( poly1, poly2, res );
            return true;
        }
        else
        {
            if ( isConvex ( poly2 ) )
            {
                intersect1c ( poly2, poly1, res );
                return true;
            }
        }
    }
// ������ ������ ������������� � ������� �������� �� ������
    nat n1 = poly1.size();
    nat n2 = poly2.size();
    Vector2d * vert1 = poly1();
    Vector2d * vert2 = poly2();
    if ( fabs ( area1 ) < fabs ( area2 ) )
    {
        _swap ( n1, n2 );
        _swap ( vert1, vert2 );
        _swap ( area1, area2 );
    }
    CArrRef<Vector2d> p1 ( vert1, n1 );
    CArrRef<Vector2d> p2 ( vert2, n2 );
// ������� ����� ����������� ������ ���������������
    Suite<Set4<Vector2d, nat, nat, bool> > vert;
    SortItem<double, Set4<Vector2d, nat, nat, bool> > v;
    Suite<SortItem<double, Set4<Vector2d, nat, nat, bool> > > arr;
    for ( i = 0; i < n1; ++i )
    {
        const Vector2d & va1 = p1[i];
        const Vector2d & vb1 = p1.cnext(i);
        const Vector2d dir1 ( vb1 - va1 );
        arr.resize();
        for ( j = 0; j < n2; ++j )
        {
            const Vector2d & va2 = p2[j];
            const Vector2d & vb2 = p2.cnext(j);
            const Vector2d dir2 ( vb2 - va2 );
            const Vector2d a2a1 ( va2 - va1 );
            const Vector2d b2a1 ( vb2 - va1 );
            const Vector2d a2b1 ( va2 - vb1 );
            const Vector2d b2b1 ( vb2 - vb1 );
            const double a1 = ( a2a1 * a2a1 < a2b1 * a2b1 ? a2a1 : a2b1 ) % dir1;
            const double b1 = ( b2a1 * b2a1 < b2b1 * b2b1 ? b2a1 : b2b1 ) % dir1;
            const double c1 = a1 * b1;
            if ( c1 > 0 ) continue;
            const double a2 = dir2 % ( a2a1 * a2a1 < b2a1 * b2a1 ? a2a1 : b2a1 );
            const double b2 = dir2 % ( a2b1 * a2b1 < b2b1 * b2b1 ? a2b1 : b2b1 );
            const double c2 = a2 * b2;
            if ( c2 > 0  ) continue;
            if ( c1 < 0 )
            {
                if ( c2 < 0 )
                {
                    v.head = a2 / ( a2 - b2 );
                    v.tail.a = va1 + dir1 * v.head;
                }
                else
                {
                    if ( a2 ) continue;
                    const Vector2d dir0 ( va1 - p1.cprev(i) );
                    if ( dir0 % dir1 < 0 )
                    {
                        v.tail.d = b1 > 0 && b2a1 % dir0 > 0;
                        if ( v.tail.d == ( a1 > 0 && a2a1 % dir0 > 0 ) ) continue;
                    }
                    else
                    {
                        v.tail.d = b1 > 0 || b2a1 % dir0 > 0;
                        if ( v.tail.d == ( a1 > 0 || a2a1 % dir0 > 0 ) ) continue;
                    }
                    v.head = 0;
                    v.tail.a = va1;
                }
                v.tail.d = b1 > 0;
            }
            else
            {
                if ( a1 ) continue;
                if ( ! b1 ) // ���� ����� �� ����� ������
                {
                    if ( a2a1 * dir1 < 0 && ( vb2 - va1 ) * dir1 > 0 ) continue;
                }
                const Vector2d ue1 ( p2.cprev(j) - va1 );
                if ( c2 < 0 )
                {
                    if ( ( b1 <= 0 ) == ( ue1 % dir1 <= 0 ) ) continue;
                    v.tail.d = b1 > 0;
                    v.head = a2 / ( a2 - b2 );
                }
                else
                {
                    if ( a2 ) continue;
                    const Vector2d & vc1 = p1.cprev(i);
                    const Vector2d dir0 ( va1 - vc1 );
                    const Vector2d uc1 ( p2.cprev(j) - vc1 );
                    if ( dir0 % dir1 < 0 )
                    {
                        v.tail.d = b1 > 0 && b2a1 % dir0 > 0;
                        if ( v.tail.d == ( ue1 % dir1 > 0 && uc1 % dir0 > 0 ) ) continue;
                    }
                    else
                    {
                        v.tail.d = b1 > 0 || b2a1 % dir0 > 0;
                        if ( v.tail.d == ( ue1 % dir1 > 0 || uc1 % dir0 > 0 ) ) continue;
                    }
                    v.head = 0;
                }
                v.tail.a = va2;
            }
            v.tail.b = i;
            v.tail.c = j;
            arr.inc() = v;
        }
        insertSort123 ( arr );
        for ( j = 0; j < arr.size(); ++j )
        {
            if ( vert.size() > 0 && vert.las().a == arr[j].tail.a )
                vert.dec();
            else
                vert.inc() = arr[j].tail;
        }
    }
    if ( vert.size() > 0 )
    {
        nat pre = vert.size() - 1;
        for ( nat cur = 0; cur < vert.size(); ++cur )
        {
            if ( vert[pre].d == vert[cur].d )
            {
                return false;
            }
            pre = cur;
        }
    }
    if ( vert.size() > 0 && vert.las().a == vert[0].a )
    {
        for ( j = 2; j < vert.size(); ++j ) vert[j-2] = vert[j-1];
        vert.dec ( 2 );
    }
// ������, ����� ������� ��������������� �� ������������
    if ( vert.size() == 0 )
    {
        Vector2d o = null2d;
        o += p2;
        o /= n2;
        if ( area1 > 0 == isIntersect ( o, p1 ) ) res.inc() = p2;
        if ( area2 < 0 ) res.inc() = p1;
        return true;
    }
// ������, ����� ������� ��������������� ������������
    if ( vert.size() == 2 )
    {
        const Set4<Vector2d, nat, nat, bool> & oa = vert[0].d ? vert[0] : vert[1];
        const Set4<Vector2d, nat, nat, bool> & ob = vert[0].d ? vert[1] : vert[0];
        Suite<Vector2d> & p3 = res.inc();
        p3.resize();
        if ( oa.b == ob.b )
        {
            if ( ( ob.a - oa.a ) * ( p1.cnext(oa.b) - p1[oa.b] ) < 0 )
            {
                for ( i = 1; i <= n1; ++i )
                {
                    j = oa.b + i;
                    if ( j >= n1 ) j -= n1;
                    put ( p3, p1[j] );
                }
            }
        }
        else
        {
            for ( i = oa.b;; )
            {
                if ( i == ob.b ) break;
                if ( ++i == n1 ) i = 0;
                put ( p3, p1[i] );
            }
        }
        put ( p3, ob.a );
        if ( oa.c == ob.c )
        {
            if ( ( ob.a - oa.a ) * ( p2.cnext(oa.c) - p2[oa.c] ) > 0 )
            {
                for ( i = 1; i <= n2; ++i )
                {
                    j = oa.c + i;
                    if ( j >= n2 ) j -= n2;
                    put ( p3, p2[j] );
                }
            }
        }
        else
        {
            for ( i = ob.c;; )
            {
                if ( i == oa.c ) break;
                if ( ++i == n2 ) i = 0;
                put ( p3, p2[i] );
            }
        }
        if ( p3[0] != oa.a && p3.las() != oa.a ) p3.inc() = oa.a;
        if ( p3.size() < 3 ) res.dec();
    }
    else
    {
        List2n list;
        DynArray<SortItem<Set2<nat, double>, nat> > temp ( vert.size() );
        j = vert[0].d ? 0 : 1;
        for ( i = 0; i < vert.size(); i += 2 )
        {
            Item2n * item = new Item2n;
            item->a = i + j;
            item->b = item->a + 1;
            if ( item->b == vert.size() ) item->b = 0;
            list.addAftLas ( item );
        }
        for ( i = 0; i < vert.size(); ++i )
        {
            j = vert[i].c;
            const double t = ( p2.cnext(j) - p2[j] ).setNorm2() * vert[i].a;
            temp[i].head.a = j;
            temp[i].head.b = t;
            temp[i].tail = i;
        }
        insertSort123 ( temp );
        if ( vert[temp[0].tail].d ) temp >>= 1;
        for ( i = 0; i < temp.size(); ++i )
        {
            Item2n * item = new Item2n;
            item->a = temp[i].tail;
            ++i;
            item->b = temp[i].tail;
            list.addAftLas ( item );
        }
        List<ListItem<List2n> > itog;
        makeClosed ( list, itog );
        res.resize ( itog.size() ).resize();
        if ( itog.top() )
        do
        {
            Suite<Vector2d> & p3 = res.inc();
            p3.resize();
            List2n * zol = itog.cur();
            nat ia = zol->top()->a;
            do
            {
                const nat ib = zol->cur()->b;
                const Set4<Vector2d, nat, nat, bool> & oa = vert[ia];
                const Set4<Vector2d, nat, nat, bool> & ob = vert[ib];
                if ( vert[ia].d )
                {
                    if ( oa.b == ob.b )
                    {
                        if ( ( ob.a - oa.a ) * ( p1.cnext(oa.b) - p1[oa.b] ) < 0 )
                        {
                            for ( i = 1; i <= n1; ++i )
                            {
                                j = oa.b + i;
                                if ( j >= n1 ) j -= n1;
                                put ( p3, p1[j] );
                            }
                        }
                    }
                    else
                    {
                        for ( i = oa.b;; )
                        {
                            if ( i == ob.b ) break;
                            if ( ++i == n1 ) i = 0;
                            put ( p3, p1[i] );
                        }
                    }
                    put ( p3, ob.a );
                    ia = ib;
                }
                else
                {
                    if ( oa.c == ob.c )
                    {
                        if ( ( ob.a - oa.a ) * ( p2.cnext(oa.c) - p2[oa.c] ) < 0 )
                        {
                            for ( i = 1; i <= n2; ++i )
                            {
                                j = oa.c + i;
                                if ( j >= n2 ) j -= n2;
                                put ( p3, p2[j] );
                            }
                        }
                    }
                    else
                    {
                        for ( i = oa.c;; )
                        {
                            if ( i == ob.c ) break;
                            if ( ++i == n2 ) i = 0;
                            put ( p3, p2[i] );
                        }
                    }
                    put ( p3, ob.a );
                    ia = ib;
                }
            }
            while ( zol->next() );
            if ( p3.las() == p3[0] ) p3.dec();
            if ( p3.size() < 3 ) res.dec();
        }
        while ( itog.next() );
    }
    return true;
}

bool intersectPolygons ( CCArrRef<Vector2d> & poly1, CCArrRef<Vector2d> & poly2, Suite< Suite<Vector2d> > & res )
{
    res.resize();
    if ( poly1.size() < 3 || poly2.size() < 3 ) return true;
    Suite<Vector2d> p1 ( poly1.size() ), p2 ( poly2.size() );
    nat i;
    for ( i = 0; i < poly1.size(); ++i )
    {
        if ( poly1[i] != poly1.cprev(i) ) p1.inc() = poly1[i];
    }
    for ( i = 0; i < poly2.size(); ++i )
    {
        if ( poly2[i] != poly2.cprev(i) ) p2.inc() = poly2[i];
    }
    return intersection ( p1, p2, res );
}

bool differencePolygons ( CCArrRef<Vector2d> & poly1, CCArrRef<Vector2d> & poly2, Suite< Suite<Vector2d> > & res )
{
    res.resize(0);
    if ( poly1.size() < 3 || poly2.size() < 3 ) return true;
    Suite<Vector2d> p1 ( poly1.size() ), p2 ( poly2.size() );
    nat i;
    for ( i = 0; i < poly1.size(); ++i )
    {
        if ( poly1[i] != poly1.cprev(i) ) p1.inc() = poly1[i];
    }
    for ( i = 0; i < poly2.size(); ++i )
    {
        if ( poly2[i] != poly2.cprev(i) ) p2.inc() = poly2[i];
    }
    return intersection ( p1, p2.reverse(), res );
}

bool unionPolygons ( CCArrRef<Vector2d> & poly1, CCArrRef<Vector2d> & poly2, Suite< Suite<Vector2d> > & res )
{
    res.resize(0);
    if ( poly1.size() < 3 || poly2.size() < 3 ) return true;
    Suite<Vector2d> p1 ( poly1.size() ), p2 ( poly2.size() );
    nat i;
    for ( i = 0; i < poly1.size(); ++i )
    {
        if ( poly1[i] != poly1.cprev(i) ) p1.inc() = poly1[i];
    }
    for ( i = 0; i < poly2.size(); ++i )
    {
        if ( poly2[i] != poly2.cprev(i) ) p2.inc() = poly2[i];
    }
    if ( ! intersection ( p1.reverse(), p2.reverse(), res ) )
        return false;
    for ( i = 0; i < res.size(); ++i ) res[i].reverse();
    return true;
}

//**************************** 24.11.2023 *********************************//
//
//           ����������� �������������� ���������� ����� ���������
//
//**************************** 15.12.2023 *********************************//

bool intersectHalfPlanes ( CCArrRef<Line2d> & line, DynArrRef<Vector2d> & poly )
{
    const nat n = line.size();
    if ( n < 3 )
        return false;
    nat i;
// ������������ ��������������
    DynArray<Vector2d> point ( n );
    for ( i = 0; i < n; ++i )
    {
        const Line2d & p = line[i];
        if ( p.dist >= 0 )
            return false;
        Vector2d & v = point[i];
        v.x = p.norm.x / p.dist;
        v.y = p.norm.y / p.dist;
    }
// ���������� �������� ��������
    Suite<nat> index;
    convexNlogN ( point, index );
    const nat nv = index.size();
    if ( nv < 3 )
        return false;
// ���������� �������������� � ������������ ���������������
    poly.resize ( nv );
    nat ip = index.las();
    for ( i = 0; i < nv; ++i )
    {
        const nat ic = index[i];
        const Vector2d & a = point[ip];
        const Vector2d & b = point[ic];
        const Vector2d norm ( a.y - b.y, b.x - a.x );
        const double dist = - ( norm * b );
        if ( ! dist )
            return false;
        poly[i] = Vector2d (norm.x / dist, norm.y / dist);
        ip = ic;
    }
    return true;
}
