
#ifndef SEMIRIB_H
#define SEMIRIB_H

struct SemiRib
{
    unsigned int next;
    unsigned int twin;
    unsigned int vert;
};

#endif